
            function appGdata(){
                return "79318";
            }
            function appTitle(){
                return "西师爱阅";
            }
            function appDescription(){
                return "展示了三亚旅游指南";
            }
            function tabBarPagePath(){
                return ["\/pages\/page10000\/page10000","\/pages\/page10001\/page10001","\/pages\/page10002\/page10002","\/pages\/page10003\/page10003"];
            }
            function homePageName(){
                return "page10000";
            }
            function Allpages(){
                return ["pages\/page10000\/page10000","otherpage\/busicardDetail\/busicardDetail","pages\/memberCard\/memberCard","pages\/myCoupon\/myCoupon","pages\/receiveCou\/receiveCou","pages\/webpreview\/webpreview","pages\/sellerJoin\/sellerJoin","pages\/wifi_page\/wifi_page","pages\/newCoupon\/newCoupon","pages\/newMemberDetail\/newMemberDetail","pages\/consumeDetail\/consumeDetail","pages\/filladdress\/filladdress","pages\/changeInfo\/changeInfo","pages\/addgoodsTip\/addgoodsTip","pages\/checkpage\/checkpage","pages\/redDispatch\/redDispatch","pages\/couponDetail\/couponDetail","pages\/online_buy\/online_buy","pages\/page10001\/page10001","shequ\/addTopic\/addTopic","shequ\/addTopicComment\/addTopicComment","shequ\/forumDetail\/forumDetail","shequ\/forumNotice\/forumNotice","shequ\/forumUserInfo\/forumUserInfo","shequ\/searchTopic\/searchTopic","shequ\/topicDetail\/topicDetail","pages\/page10002\/page10002","pages\/userinfo\/userinfo","pages\/userset\/userset","pages\/myMessage\/myMessage","pages\/messageList\/messageList","pages\/address\/address","dianshang\/createOrder\/createOrder","dianshang\/evaluate\/evaluate","dianshang\/goodsClassify\/goodsClassify","dianshang\/goodsDetail\/goodsDetail","dianshang\/goodsEvaluate\/goodsEvaluate","dianshang\/goodsList\/goodsList","pages\/myOrder\/myOrder","dianshang\/orderDetail\/orderDetail","dianshang\/searchGoods\/searchGoods","pages\/shopCart\/shopCart","dianshang\/settlement\/settlement","dianshang\/seckillDetail\/seckillDetail","dianshang\/newseckillDetail\/newseckillDetail","pages\/selAddress\/selAddress","dianshang\/searchSeck\/searchSeck","dianshang\/distDetail\/distDetail","dianshang\/searchDist\/searchDist","dianshang\/bindphone\/bindphone","dianshang\/cashpage\/cashpage","dianshang\/cashsuccess\/cashsuccess","dianshang\/discashlist\/discashlist","dianshang\/disorder\/disorder","pages\/distribution\/distribution","dianshang\/introduce\/introduce","dianshang\/myTeam\/myTeam","dianshang\/goodsextension\/goodsextension","dianshang\/searchSubGoods\/searchSubGoods","dianshang\/shopHome\/shopHome","dianshang\/homeSearch\/homeSearch","dianshang\/good_classification\/good_classification","dianshang\/rageDetail\/rageDetail","dianshang\/cashRecord\/cashRecord","dianshang\/newdisorder\/newdisorder","pages\/iWantDis\/iWantDis","dianshang\/disApply\/disApply","dianshang\/lower_member\/lower_member","dianshang\/myDeposit\/myDeposit","dianshang\/mydisOrder\/mydisOrder","dianshang\/searchNewDist\/searchNewDist","dianshang\/searchDistpro\/searchDistpro","dianshang\/withdrawal\/withdrawal","dianshang\/wechatCash\/wechatCash","dianshang\/bankcardCash\/bankcardCash","dianshang\/disProduct\/disProduct","dianshang\/myseckOrder\/myseckOrder","dianshang\/seckGoodsorderdetails\/seckGoodsorderdetails","dianshang\/searchGoodsshop\/searchGoodsshop","pintuan\/createGrouporder\/createGrouporder","pintuan\/groupGoodsdetail\/groupGoodsdetail","pintuan\/groupGoodsmore\/groupGoodsmore","pintuan\/groupGoodsorderdetails\/groupGoodsorderdetails","pintuan\/searchGroupgoods\/searchGroupgoods","pintuan\/myGrouporder\/myGrouporder","pintuan\/rebate_detail\/rebate_detail","pintuan\/groupDeposit\/groupDeposit","pintuan\/groupInvitation\/groupInvitation","pages\/page10003\/page10003","pages\/page10005\/page10005","pages\/page10006\/page10006","pages\/page10007\/page10007","pages\/page10008\/page10008","pages\/page10009\/page10009","pages\/page10010\/page10010","pages\/page10011\/page10011","pages\/page10012\/page10012","pages\/page10013\/page10013","pages\/page10014\/page10014","pages\/page10015\/page10015","pages\/page10016\/page10016","pages\/page10017\/page10017","pages\/page10018\/page10018","pages\/page10019\/page10019","pages\/page10020\/page10020","pages\/page10021\/page10021","pages\/page10022\/page10022","pages\/page10023\/page10023","pages\/page10024\/page10024","pages\/page10026\/page10026","pages\/page10027\/page10027","pages\/page10028\/page10028","pages\/page10029\/page10029","pages\/page10030\/page10030","pages\/page10031\/page10031","pages\/page10032\/page10032","pages\/page10033\/page10033","pages\/page10044\/page10044","pages\/page10045\/page10045"]
            }
            function siteUrl(){
                return "https://api.haouxi.com"
            }
            function weburl(){
                return "https://api.haouxi.com"
            }
            module.exports={
                appGdata: appGdata,
                appTitle: appTitle,
                appDescription: appDescription,
                tabBarPagePath: tabBarPagePath,
                homePageName:homePageName,
                Allpages:Allpages,
                siteUrl:siteUrl,
                weburl:weburl
            }