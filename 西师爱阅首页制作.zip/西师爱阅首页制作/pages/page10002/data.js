
                    function appData(){
                        var mappDate = {"topNav0":"","bottomNav1":"","forumList2":{"type":"forumList","style":"position:relative;margin-top:0px;opacity:1;background:#ffffff;","content":[{"pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/emptyimg.png","title":"\u7248\u5757\u6807\u9898","imgStyle":"width:750.00000rpx;height:421.87500rpx;margin-left:0px;","listStyle":"background:#ffffff;height:562.50000rpx;margin-bottom:0px;","titleWidth":"width:726.56250rpx;vertical-align:top;","titlefont":"font-size:37.50000rpx;font-style:normal;font-weight:bold;text-decoration:none;text-align:left;color:rgb(48, 170, 245);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:#626262;"},{"pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/emptyimg.png","title":"\u7248\u5757\u6807\u9898","imgStyle":"width:750.00000rpx;height:421.87500rpx;margin-left:0px;","listStyle":"background:#ffffff;height:562.50000rpx;margin-bottom:0px;","titleWidth":"width:726.56250rpx;vertical-align:top;","titlefont":"font-size:37.50000rpx;font-style:normal;font-weight:bold;text-decoration:none;text-align:left;color:rgb(48, 170, 245);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:#626262;"}],"imgStyle":"width:750.00000rpx;height:421.87500rpx;margin-left:0px;","listStyle":"background:#ffffff;height:562.50000rpx;margin-bottom:0px;","titleWidth":"width:726.56250rpx;vertical-align:top;","titlefont":"font-size:37.50000rpx;font-style:normal;font-weight:bold;text-decoration:none;text-align:left;color:rgb(48, 170, 245);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:#626262;","showLabel":false,"labelContent":[],"mode":true,"compid":"forumList2"},"button3":{"type":"button","style":"color:#ffffff;font-size:35.15625rpx;text-align:center;width:328.12500rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:0px;opacity:1;border-radius:14.06250rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u70b9\u51fb\u8fdb\u5165","eventHandler":"bindCommunity","eventParams":"{\"bindid\":\"1423\"}"}};
                        return mappDate;
                    }
                    function router(){
                        return "page10002";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "晒图";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [{"forumId":"1423,1423","name":"forumList2"}];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                