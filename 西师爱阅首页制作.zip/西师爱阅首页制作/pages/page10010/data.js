
                    function appData(){
                        var mappDate = {"topNav0":"","title1":{"type":"title","style":"line-height:93.75000rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(243, 243, 243);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u5929\u6daf\u6d77\u89d2 \u00b7 \u666f\u70b9\u7b80\u4ecb","markColor":"rgb(48, 170, 245)","mode":"1"},"text2":{"type":"text","style":"color:#444444;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"      \u5929\u6daf\u6d77\u89d2\u6e38\u89c8\u533a\u4f4d\u4e8e\u4e09\u4e9a\u5e02\u533a\u897f\u535723\u516c\u91cc\u5904\uff0c\u4ee5\u7f8e\u4e3d\u8ff7\u4eba\u7684\u70ed\u5e26\u6d77\u6ee8\u81ea\u7136\u98ce\u5149\u3001\u60a0\u4e45\u72ec\u7279\u7684\u5386\u53f2\u6587\u5316\u800c\u9a70\u540d\u4e2d\u5916\u3002\u540c\u65f6\uff0c\u5979\u4e5f\u662f\u6d77\u5357\u5efa\u770120\u5468\u5e74\u7b2c\u4e00\u4eae\u4e3d\u54c1\u724c\uff0c\u65b0\u4e2d\u56fd\u6210\u7acb60\u5468\u5e74\u6d77\u5357\u7b2c\u4e00\u54c1\u724c\u548c\u6d77\u5357\u65c5\u6e38\u7cfb\u7edf\u521b\u5148\u4e89\u4f18\u6807\u6746\u4f01\u4e1a\u3002\n      \u5929\u6daf\u6d77\u89d2\u6e38\u89c8\u533a\u91cc\u7684\u78a7\u6d77\u3001\u9752\u5c71\u3001\u767d\u6c99\u3001\u5de8\u78ca\u3001\u7901\u76d8\u6d51\u7136\u4e00\u4f53\uff0c\u6930\u6797\u3001\u6ce2\u6d9b\u3001\u6e14\u5e06\u3001\u9e25\u71d5\u3001\u4e91\u971e\u8f89\u6620\u70b9\u886c\uff0c\u5f62\u6210\u5357\u56fd\u7279\u6709\u7684\u6930\u98ce\u6d77\u97f5\uff0c\u5438\u5f15\u4e86\u5927\u6279\u6e38\u5ba2\u7684\u6155\u540d\u524d\u6765\u3002"},"map3":{"type":"map","style":"width:750.00000rpx;height:351.56250rpx;margin-top:23.43750rpx;margin-left:0px;color:#38761d;font-size:30.46875rpx;text-align:center;font-weight:normal;font-style:normal;text-decoration:none;","showmap":true,"content":"\u6d77\u5357\u7701\u4e09\u4e9a\u5e02\u6cbf\u6d77\u6ee8\u897f\u884c26\u516c\u91cc\u9a6c\u5cad\u5c71\u4e0b","lat":18.30743,"lng":109.327209,"markers":[{"latitude":18.30743,"longitude":109.327209}],"compid":"map3"},"button4":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:4.68750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u5730\u56fe\u5bfc\u822a","eventHandler":"bindMap","eventParams":"{\"mapnid\":\"WWnFnk\",\"mapname\":\"\\u5929\\u6daf\\u6d77\\u89d2\"}"},"album5":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:28.12500rpx;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/21529133589.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/91529133624.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/71529133645.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291336786.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/71529133934.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"}]},"title6":{"type":"title","style":"line-height:70.31250rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(243, 243, 243);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u7279\u522b\u63d0\u793a","markColor":"rgb(48, 170, 245)","mode":"1"},"text7":{"type":"text","style":"color:#444444;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4ece\u666f\u533a\u5927\u95e8\u8d70\u5230\u201c\u5929\u6daf\u201d\u3001\u201c\u6d77\u89d2\u201d\u77f3\u523b\u6709\u4e00\u6bb5\u8f83\u957f\u8ddd\u79bb\uff0c\u53ef\u4ee5\u4e58\u5750\u666f\u533a\u89c2\u5149\u8f66\u524d\u5f80\u3002"},"button8":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:23.43750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u8fd4 \u56de","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10001\",\"inner_page_link\":\"\\\/pages\\\/page10001\\\/page10001\"}"},"freeVessel9":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:35.15625rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10010";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "天涯海角";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                