
                    function appData(){
                        var mappDate = {"topNav0":"","album1":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:0px;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293729273.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293729273.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293729434.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293729434.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293729533.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293729533.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293732151.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293732151.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293729673.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293729673.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293729763.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293729763.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293729882.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293729882.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293732356.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293732356.png\"}"}]},"freeVessel2":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:145.31250rpx;","content":[{"type":"picture","style":"width:140.62500rpx;height:140.62500rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:592.96875rpx;top:0px;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292402831.jpg"},"eventHandler":"bindMap","eventParams":"{\"mapnid\":\"AjgWzw\",\"mapname\":\"\\u8708\\u652f\\u6d32\\u5c9b\\u73ca\\u745a\\u9152\\u5e97\"}","imgstyle":"height:140.62500rpx"},{"type":"text","style":"color:#353535;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:527.34375rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:58.59375rpx;top:75.00000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4e09\u4e9a\u5e02\u6d77\u68e0\u533a\u6d77\u68e0\u6e7e\u8708\u652f\u6d32\u5c9b\u666f\u533a\u5185"},{"type":"text","style":"color:#000000;font-size:35.15625rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:323.43750rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:14.06250rpx;top:14.06250rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u8708\u652f\u6d32\u5c9b\u73ca\u745a\u9152\u5e97"},{"type":"picture","style":"width:46.87500rpx;height:46.87500rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:28.12500rpx;top:77.34375rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292408424.png"},"imgstyle":"height:46.87500rpx"}]},"text3":{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:9.37500rpx;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:rgb(255, 153, 0);box-shadow:rgb(255, 153, 0) 0px 1px 2px;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:23.43750rpx;","content":"\u8ba2\u623f\u70ed\u7ebf\uff1a0898-88853666","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089888853666\"}"},"freeVessel4":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:93.75000rpx;","content":[{"type":"text","style":"color:#38761d;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:609.37500rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:70.31250rpx;top:16.40625rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6682\u4e0d\u652f\u6301\u5728\u7ebf\u8ba2\u623f\uff0c\u8bf7\u76f4\u63a5\u7535\u8bdd\u9884\u7ea6\uff01"}]},"title5":{"type":"title","style":"line-height:70.31250rpx;margin-top:14.06250rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(255, 255, 255);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u9152\u5e97\u4ecb\u7ecd","markColor":"rgb(48, 170, 245)","mode":0},"text6":{"type":"text","style":"color:#626262;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:679.68750rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"       \u4e09\u4e9a\u8708\u652f\u6d32\u5c9b\u73ca\u745a\u9152\u5e97\u5730\u5904\u6d77\u5357\u7701\u8708\u652f\u6d32\u5c9b\u897f\u5317\u89d2\uff0c\u5468\u56f4\u7f8e\u4eba\u9c7c\u96d5\u5851\u3001\u751f\u547d\u4e95\u3001\u52a8\u7269\u4e50\u56ed\u7b49\u666f\u70b9\u6797\u7acb\u3002\n\u3000\u3000\u5c9b\u4e0a\u98ce\u5149\u8ff7\u4eba\u3001\u6d77\u5929\u4e00\u7ebf\uff0c\u5915\u9633\u548c\u6d77\u8272\u9759\u9759\u76f8\u4f1a\uff0c\u7ec6\u817b\u767d\u6c99\u5c42\u5c42\u94fa\u5728\u5cb8\u8fb9\u3002\u9152\u5e97\u75314\u680b\u73ca\u745a\u72b6\u7684\u8fde\u4f53\u5efa\u7b51\u76f8\u8fde\uff0c\u878d\u5408\u5404\u79cd\u6d77\u6d0b\u5143\u7d20\uff0c\u8ba9\u60a8\u5982\u540c\u6d77\u5e95\u7cbe\u7075\u7f6e\u8eab\u4e8e\u5357\u6d77\u4e4b\u6ee8\u3002\n"},"button7":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:23.43750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u8fd4 \u56de","eventHandler":"tapBack"},"freeVessel8":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:35.15625rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10021";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "蜈支洲岛珊瑚酒店";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                