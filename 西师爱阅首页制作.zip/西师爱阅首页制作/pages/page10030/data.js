
                    function appData(){
                        var mappDate = {"topNav0":"","album1":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:0px;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15294000289.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15294000289.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15294000393.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15294000393.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15294000509.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15294000509.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15294000597.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15294000597.png\"}"}]},"freeVessel2":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:145.31250rpx;","content":[{"type":"picture","style":"width:140.62500rpx;height:140.62500rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:595.31250rpx;top:0px;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292402831.jpg"},"eventHandler":"bindMap","eventParams":"{\"mapnid\":\"jVIXAo\",\"mapname\":\"\\u6d6a\\u6f2b\\u6d77\\u666f\\u516c\\u5bd3\"}","imgstyle":"height:140.62500rpx"},{"type":"text","style":"color:#353535;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:499.21875rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:58.59375rpx;top:75.00000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4e09\u4e9a\u6e7e\u5170\u6d77\u82b1\u56ed\u4e8c\u671f\u542c\u6d9b\u9601210\u5ba4"},{"type":"text","style":"color:#000000;font-size:35.15625rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:274.21875rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:7.03125rpx;top:14.06250rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6d6a\u6f2b\u6d77\u666f\u516c\u5bd3"},{"type":"picture","style":"width:46.87500rpx;height:46.87500rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:28.12500rpx;top:77.34375rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292408424.png"},"imgstyle":"height:46.87500rpx"}]},"text3":{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:9.37500rpx;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:rgb(255, 153, 0);box-shadow:rgb(255, 153, 0) 0px 1px 2px;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:23.43750rpx;","content":"\u8ba2\u623f\u70ed\u7ebf\uff1a0898-38230982","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089838230982\"}"},"text4":{"type":"text","style":"color:#38761d;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:93.75000rpx;background:rgba(0,0,0,0);width:750.00000rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:0px;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6682\u4e0d\u652f\u6301\u5728\u7ebf\u8ba2\u623f\uff0c\u8bf7\u76f4\u63a5\u7535\u8bdd\u9884\u7ea6\uff01"},"title5":{"type":"title","style":"line-height:70.31250rpx;margin-top:14.06250rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(255, 255, 255);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u9152\u5e97\u4ecb\u7ecd","markColor":"rgb(48, 170, 245)","mode":0},"text6":{"type":"text","style":"color:#626262;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:679.68750rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"       \u4e09\u4e9a\u6d6a\u6f2b\u6d77\u666f\u516c\u5bd3\u4f4d\u4e8e\u4e09\u4e9a\u6e7e\u5170\u6d77\u82b1\u56ed\u4e8c\u671f\u3001\u4e09\u671f\u3001\u6d77\u5761\u6d77\u9614\u5929\u7a7a\u5c0f\u533a\u7b49\u591a\u5904\u4e09\u4e9a\u4e00\u7ebf\u6d77\u666f\u7684\u9ad8\u6863\u793e\u533a\uff0c\u5176\u72ec\u5177\u4e00\u683c\u7684\u70ed\u5e26\u6d77\u6ee8\u88c5\u4fee\u98ce\u683c\uff0c\u4eba\u6027\u5316\u7684\u5bb6\u5c45\u7535\u5668\u914d\u7f6e\uff0c\u8ba9\u4f60\u5145\u5206\u4f53\u9a8c\u4e09\u4e9a\u4e4b\u65c5\u7684\u8212\u9002\u4e0e\u65b9\u4fbf\uff0c\u8ba9\u4f60\u611f\u53d7\u5230\u5bb6\u5ead\u5f0f\u4f4f\u5bbf\u7684\u6e29\u99a8\u670d\u52a1\uff01\n\u3000\u3000\u4e09\u4e9a\u6d6a\u6f2b\u6d77\u666f\u516c\u5bd3\u4f4d\u4e8e\u5170\u6d77\u82b1\u56ed\u4e8c\u671f\u548c\u5170\u6d77\u82b1\u56ed\u4e09\u671f\u5185\uff0c\u72ec\u95e8\u72ec\u6237\u7684\u677f\u5f0f\u7ed3\u6784\uff0c\u524d\u540e\u901a\u900f\uff0c\u72ec\u7acb\u516c\u5bd3\u623f\u9762\u79ef\u572846-70\u591a\u5e73\u7c73\u4e4b\u95f4\uff0c\u5177\u6709\u4e94\u661f\u9152\u5e97\u4e00\u6837\u72ec\u7acb\u7684\u623f\u5c4b\u7ed3\u6784,\u4fdd\u62a4\u4e86\u5ba2\u4eba\u7684\u79c1\u5bc6\u6027\u3002\u6bcf\u5957\u516c\u5bd3\u623f\u81ea\u5e26\u6709\u5c0f\u53a8\u623f,\u4e13\u95e8\u914d\u7f6e\u4e86\u5fae\u6ce2\u7089\uff0c\u51b0\u7bb1\uff0c\u6d17\u8863\u673a\uff0c\u7279\u522b\u65b9\u4fbf\u643a\u6709\u5c0f\u5b69\u548c\u8001\u4eba\u5916\u51fa\u6e21\u5047\u7684\u5bb6\u5ead\u3002"},"button7":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:23.43750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u8fd4 \u56de","eventHandler":"tapBack"},"freeVessel8":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:35.15625rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10030";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "浪漫海景公寓";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                