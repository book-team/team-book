
                    function appData(){
                        var mappDate = {"topNav0":"","teletext1":{"type":"teletext","style":"width:100%;margin-top:0px;background:#ffffff;opacity:1;","content":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/11529218391.jpg","title":"\u6d77\u5357\u6e05\u8865\u51c9","secTitle":"\u5c06\u7ea2\u67a3\u3001\u7eff\u8c46\u3001\u858f\u7c73\u3001\u828b\u5934\u3001\u897f\u74dc\u3001\u9e4c\u9e51\u86cb\u3001\u6c64\u5706\u7b49\u716e\u719f\u7684\u4e1c\u897f\uff0c\u63ba\u4e0a\u6930\u5b50\u6c41\u6216\u7cd6\u6c34\u7b49\u8c03\u548c\u6210\u4e00\u7897\u6d88\u6691\u6e05\u723d\u7684\u996e\u54c1\u3002\u5728\u6d77\u5357\u708e\u70ed\u7684\u508d\u665a\uff0c\u559d\u4e0a\u4e00\u7897\u51b0\u723d\u7684\u6e05\u8865\u51c9\u5b9e\u5728\u662f\u60ec\u610f\u7684\u4e8b\u60c5\u3002","imgStyle":"width:750.00000rpx;height:351.56250rpx;margin-left:0px;","listStyle":"background:rgb(255, 255, 255);height:468.75000rpx;margin-bottom:18.75000rpx;","titleWidth":"width:726.56250rpx;vertical-align:top;","titlefont":"font-size:35.15625rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:rgb(39, 78, 19);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:#626262;"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/21529218639.jpg","title":"\u52a0\u79ef\u9e2d","secTitle":"\u812f\u5927\u3001\u76ae\u8584\u3001\u9aa8\u8f6f\u3001\u8089\u5ae9\uff0c\u5165\u53e3\u80a5\u800c\u4e0d\u817b","imgStyle":"width:750.00000rpx;height:351.56250rpx;margin-left:0px;","listStyle":"background:rgb(255, 255, 255);height:468.75000rpx;margin-bottom:18.75000rpx;","titleWidth":"width:726.56250rpx;vertical-align:top;","titlefont":"font-size:35.15625rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:rgb(39, 78, 19);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:#626262;"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/81529218667.jpg","title":"\u6587\u660c\u9e21","secTitle":"\u6d77\u5357\u5730\u533a\u6700\u8d1f\u76db\u540d\u7684\u6c49\u65cf\u4f20\u7edf\u540d\u83dc\uff0c\u6d77\u5357\u56db\u5927\u540d\u83dc\u4e4b\u9996","imgStyle":"width:750.00000rpx;height:351.56250rpx;margin-left:0px;","listStyle":"background:rgb(255, 255, 255);height:468.75000rpx;margin-bottom:18.75000rpx;","titleWidth":"width:726.56250rpx;vertical-align:top;","titlefont":"font-size:35.15625rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:rgb(39, 78, 19);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:#626262;"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/51529218936.jpg","title":"\u548c\u4e50\u87f9","secTitle":"\u4ea7\u4e8e\u6d77\u5357\u4e07\u5b81\u53bf\u548c\u4e50\u9547\uff0c\u4ee5\u7532\u58f3\u575a\u786c\u3001\u8089\u80a5\u818f\u591a\u8457\u79f0\uff0c\u4e0e\u6587\u660c\u9e21\u3001\u52a0\u79ef\u9e2d\u3001\u4e1c\u5c71\u7f8a\u5e76\u5217\u4e3a\u6d77\u5357\u56db\u5927\u540d\u4ea7\u3002","imgStyle":"width:750.00000rpx;height:351.56250rpx;margin-left:0px;","listStyle":"background:rgb(255, 255, 255);height:468.75000rpx;margin-bottom:18.75000rpx;","titleWidth":"width:726.56250rpx;vertical-align:top;","titlefont":"font-size:35.15625rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:rgb(39, 78, 19);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:#626262;"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/91529219091.jpg","title":"\u62b1\u7f57\u7c89","secTitle":"\u62b1\u7f57\u7c89\u5c5e\u6c64\u7c89\u7c7b\uff0c\u5176\u8d35\u5728\u6c64\u597d\uff0c\u9c9c\u7f8e\u53ef\u53e3\uff0c\u9999\u751c\u9ebb\u8fa3","imgStyle":"width:750.00000rpx;height:351.56250rpx;margin-left:0px;","listStyle":"background:rgb(255, 255, 255);height:468.75000rpx;margin-bottom:18.75000rpx;","titleWidth":"width:726.56250rpx;vertical-align:top;","titlefont":"font-size:35.15625rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:rgb(39, 78, 19);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:#626262;"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292191058.jpg","title":"\u4e1c\u5c71\u7f8a","secTitle":"\u8198\u80a5\u76ae\u8584\u8089\u5ae9\u65e0\u81bb\u53ca\u76ae\u4e0b\u8102\u80aa\u9002\u4e2d\u3001\u80a5\u800c\u4e0d\u817b\u3001\u6c64\u5473\u6d53\u7a20\u4e73\u767d\u3001\u6c14\u5473\u82b3\u9999\u3001\u5473\u9053\u9c9c\u7f8e","imgStyle":"width:750.00000rpx;height:351.56250rpx;margin-left:0px;","listStyle":"background:rgb(255, 255, 255);height:468.75000rpx;margin-bottom:18.75000rpx;","titleWidth":"width:726.56250rpx;vertical-align:top;","titlefont":"font-size:35.15625rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:rgb(39, 78, 19);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:#626262;"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292191603.jpg","title":"\u51ac\u74dc\u6d77\u87ba\u6c64","secTitle":"\u88ab\u79f0\u4f5c\u6d77\u5357\u7b2c\u4e00\u6c64\uff0c\u662f\u5f53\u5730\u5fc5\u5c1d\u7684\u7279\u8272\u83dc\u4e4b\u4e00","imgStyle":"width:750.00000rpx;height:351.56250rpx;margin-left:0px;","listStyle":"background:rgb(255, 255, 255);height:468.75000rpx;margin-bottom:18.75000rpx;","titleWidth":"width:726.56250rpx;vertical-align:top;","titlefont":"font-size:35.15625rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:rgb(39, 78, 19);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:#626262;"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/81529219282.jpg","title":"\u6930\u5b50\u996d","secTitle":"\u5916\u8fb9\u662f\u6930\u8089\uff0c\u91cc\u9762\u662f\u7c98\u7c73\uff0c\u52a0\u4e0a\u7279\u6b8a\u7684\u9999\u6599\u653e\u5728\u9505\u91cc\u9762\u84b8","imgStyle":"width:750.00000rpx;height:351.56250rpx;margin-left:0px;","listStyle":"background:rgb(255, 255, 255);height:468.75000rpx;margin-bottom:18.75000rpx;","titleWidth":"width:726.56250rpx;vertical-align:top;","titlefont":"font-size:35.15625rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:rgb(39, 78, 19);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:center;color:#626262;"}]},"title2":{"type":"title","style":"line-height:93.75000rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:#efefef;color:#000000;text-align:left;font-size:35.15625rpx;","content":"\u63a8\u8350\u9910\u5385","markColor":"rgb(48, 170, 245)","mode":"1"},"teletext3":{"type":"teletext","style":"width:100%;margin-top:18.75000rpx;background:#ffffff;opacity:1;","content":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/91529219859.jpg","title":"\u6682\u65e0\u63a8\u8350","secTitle":"\u6682\u65e0\u63a8\u8350","imgStyle":"width:234.37500rpx;height:140.62500rpx;margin-left:23.43750rpx;","listStyle":"background:rgb(243, 243, 243);height:140.62500rpx;margin-bottom:18.75000rpx;","titleWidth":"width:468.75000rpx;vertical-align:middle;","titlefont":"font-size:32.81250rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:rgb(53, 53, 53);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:rgb(136, 136, 136);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292199972.jpg","title":"\u6682\u65e0\u63a8\u8350","secTitle":"\u6682\u65e0\u63a8\u8350","imgStyle":"width:234.37500rpx;height:140.62500rpx;margin-left:23.43750rpx;","listStyle":"background:rgb(243, 243, 243);height:140.62500rpx;margin-bottom:18.75000rpx;","titleWidth":"width:468.75000rpx;vertical-align:middle;","titlefont":"font-size:32.81250rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:rgb(53, 53, 53);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:rgb(136, 136, 136);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292199911.jpg","title":"\u6682\u65e0\u63a8\u8350","secTitle":"\u6682\u65e0\u63a8\u8350","imgStyle":"width:234.37500rpx;height:140.62500rpx;margin-left:23.43750rpx;","listStyle":"background:rgb(243, 243, 243);height:140.62500rpx;margin-bottom:18.75000rpx;","titleWidth":"width:468.75000rpx;vertical-align:middle;","titlefont":"font-size:32.81250rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:rgb(53, 53, 53);","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:rgb(136, 136, 136);"}]},"button4":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:46.87500rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u8fd4 \u56de","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10000\",\"inner_page_link\":\"\\\/pages\\\/page10000\\\/page10000\"}"},"freeVessel5":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:35.15625rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10005";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "美食推荐";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                