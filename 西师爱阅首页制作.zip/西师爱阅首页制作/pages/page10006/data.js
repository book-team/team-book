
                    function appData(){
                        var mappDate = {"topNav0":"","text1":{"type":"text","style":"color:#ff9900;font-size:35.15625rpx;text-align:center;max-width:100%;line-height:93.75000rpx;background:rgba(0,0,0,0);width:750.00000rpx;font-weight:bold;font-style:normal;text-decoration:none;margin-top:0px;margin-left:0px;margin-right:auto;border-style:none;border-width:0px;border-color:rgb(255, 153, 0);box-shadow:rgb(255, 153, 0) 0px 1px 5px;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:23.43750rpx;","content":"\u666f\u533a\u5468\u8fb9\u9152\u5e9780\u5143\u8d77"},"freeVessel2":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:rgb(204, 204, 204) 0px 1px 0px;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:351.56250rpx;","content":[{"type":"picture","style":"width:234.37500rpx;height:187.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:23.43750rpx;opacity:1;left:21.09375rpx;top:30.46875rpx;max-width:100%;line-height:187.50000rpx;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292227315.jpg"},"eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10021\",\"inner_page_link\":\"\\\/pages\\\/page10021\\\/page10021\"}","imgstyle":"height:187.50000rpx"},{"type":"text","style":"color:#000000;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:316.40625rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:257.81250rpx;top:25.78125rpx;-webkit-box-sizing:border-box;border-radius:0px;height:58.59375rpx;","content":"\u8708\u652f\u6d32\u5c9b\u73ca\u745a\u9152\u5e97"},{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:234.37500rpx;line-height:65.62500rpx;height:65.62500rpx;background:rgb(255, 153, 0);opacity:1;border-radius:11.71875rpx;box-shadow:#000000 0px 0px 0px;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;left:21.09375rpx;top:248.43750rpx;","content":"\u67e5\u770b\u8be6\u60c5","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10021\",\"inner_page_link\":\"\\\/pages\\\/page10021\\\/page10021\"}"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:438.28125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:285.93750rpx;top:93.75000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4e09\u4e9a\u8708\u652f\u6d32\u5c9b\u73ca\u745a\u9152\u5e97\u5730\u5904\u6d77\u5357\u7701\u8708\u652f\u6d32\u5c9b\u897f\u5317\u89d2\uff0c\u9152\u5e97\u914d\u5957\u6e38\u6cf3\u6c60\uff0c\u5468\u56f4\u7f8e\u4eba\u9c7c\u96d5\u5851\u3001\u751f\u547d\u4e95\u3001\u52a8\u7269\u4e50\u56ed\u7b49\u666f\u70b9\u6797\u7acb\u3002"},{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:145.31250rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:585.93750rpx;top:25.78125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u00a5880\u8d77"}]},"freeVessel3":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:rgb(204, 204, 204) 0px 1px 0px;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:351.56250rpx;","content":[{"type":"picture","style":"width:234.37500rpx;height:187.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:11.71875rpx;opacity:1;left:21.09375rpx;top:30.46875rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292399023.png"},"eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10031\",\"inner_page_link\":\"\\\/pages\\\/page10031\\\/page10031\"}","imgstyle":"height:187.50000rpx"},{"type":"text","style":"color:#000000;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:281.25000rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:257.81250rpx;top:30.46875rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u5c71\u6d77\u5929\u4e07\u8c6a\u9152\u5e97"},{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:140.62500rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:585.93750rpx;top:30.46875rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u00a5620\u8d77"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:438.28125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:285.93750rpx;top:93.75000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4eb2\u8fd1\u81ea\u7136\u3001\u5c71\u6d77\u4e00\u7ebf\u3001\u80cc\u5c71\u9762\u6d77\uff0c\u5728\u6b23\u8d4f\u6d77\u7684\u540c\u65f6\uff0c\u8fd8\u80fd\u8fdb\u884c\u6f5c\u6c34\u3001\u6d6e\u6f5c\u3001\u6c99\u6ee9\u6392\u7403\u7b49\u5404\u9879\u6d3b\u52a8\uff0c\u4e30\u5bcc\u4f60\u7684\u5047\u671f\u751f\u6d3b\u3002"},{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:234.37500rpx;line-height:65.62500rpx;height:65.62500rpx;background:rgb(255, 153, 0);opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;left:21.09375rpx;top:248.43750rpx;","content":"\u67e5\u770b\u8be6\u60c5","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10031\",\"inner_page_link\":\"\\\/pages\\\/page10031\\\/page10031\"}"}]},"freeVessel4":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:rgb(204, 204, 204) 0px 1px 0px;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:351.56250rpx;","content":[{"type":"picture","style":"width:234.37500rpx;height:187.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:23.43750rpx;opacity:1;left:21.09375rpx;top:30.46875rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292232675.jpg"},"eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10022\",\"inner_page_link\":\"\\\/pages\\\/page10022\\\/page10022\"}","imgstyle":"height:187.50000rpx"},{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:234.37500rpx;line-height:65.62500rpx;height:65.62500rpx;background:rgb(255, 153, 0);opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;left:21.09375rpx;top:248.43750rpx;","content":"\u67e5\u770b\u8be6\u60c5","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10022\",\"inner_page_link\":\"\\\/pages\\\/page10022\\\/page10022\"}"},{"type":"text","style":"color:#000000;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:290.62500rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:253.12500rpx;top:25.78125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u51e4\u51f0\u5c9b\u5ea6\u5047\u9152\u5e97"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:438.28125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:285.93750rpx;top:93.75000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4e09\u4e9a\u6e7e\u8def\u51e4\u51f0\u5c9bA\u5ea7\uff08\u6d77\u6d0b\u4e4b\u6708\uff09 \uff0c\u4f4d\u4e8e\u6d77\u4e2d\u592e\uff0c\u8fd1\u6b65\u884c\u8857\u3001\u6930\u68a6\u957f\u5eca\uff0c\u8fdc\u773a\u5357\u6d77\u89c2\u97f3\u3001\u4e1c\u897f\u73b3\u7441\u5c9b\u3001\u9e7f\u56de\u5934\u3002"},{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:145.31250rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:585.93750rpx;top:25.78125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u00a5698\u8d77"}]},"freeVessel5":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:rgb(204, 204, 204) 0px 1px 0px;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:351.56250rpx;","content":[{"type":"picture","style":"width:234.37500rpx;height:187.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:23.43750rpx;opacity:1;left:21.09375rpx;top:30.46875rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292235828.jpg"},"eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10023\",\"inner_page_link\":\"\\\/pages\\\/page10023\\\/page10023\"}","imgstyle":"height:187.50000rpx"},{"type":"text","style":"color:#000000;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:246.09375rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:260.15625rpx;top:25.78125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6d77\u97f5\u5ea6\u5047\u9152\u5e97"},{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:234.37500rpx;line-height:65.62500rpx;height:65.62500rpx;background:rgb(255, 153, 0);opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;left:21.09375rpx;top:248.43750rpx;","content":"\u67e5\u770b\u8be6\u60c5","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10023\",\"inner_page_link\":\"\\\/pages\\\/page10023\\\/page10023\"}"},{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:145.31250rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:585.93750rpx;top:25.78125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u00a5538\u8d77"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:438.28125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:285.93750rpx;top:93.75000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6d77\u97f5\u5ea6\u5047\u9152\u5e97\u4f4d\u4e8e\u4e09\u4e9a\u6e7e\u4e2d\u5fc3\u7684\u72ec\u7acb\u6c99\u6ee9\u4e0a\uff0c\u8fd1\u6930\u68a6\u957f\u5eca\u3001\u51e4\u51f0\u673a\u573a\u3001\u5929\u6daf\u6d77\u89d2\u3001\u5357\u5c71\u5bfa\u7b49\uff0c\u7d27\u90bb\u4e09\u4e9a\u51e4\u51f0\u673a\u573a\u3001\u5e02\u533a\u3001\u52a8\u8f66\u7ad9\u3002"}]},"freeVessel6":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:rgb(204, 204, 204) 0px 1px 0px;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:351.56250rpx;","content":[{"type":"picture","style":"width:234.37500rpx;height:187.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:11.71875rpx;opacity:1;left:21.09375rpx;top:30.46875rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292248706.jpg"},"eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10024\",\"inner_page_link\":\"\\\/pages\\\/page10024\\\/page10024\"}","imgstyle":"height:187.50000rpx"},{"type":"text","style":"color:#000000;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:440.62500rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:257.81250rpx;top:25.78125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u7ea2\u6811\u6797\u5ea6\u5047\u4e16\u754c(\u83e9\u63d0\u9152\u5e97)"},{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:234.37500rpx;line-height:65.62500rpx;height:65.62500rpx;background:rgb(255, 153, 0);opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;left:21.09375rpx;top:248.43750rpx;","content":"\u67e5\u770b\u8be6\u60c5","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10024\",\"inner_page_link\":\"\\\/pages\\\/page10024\\\/page10024\"}"},{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:145.31250rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:585.93750rpx;top:82.03125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u00a5360\u8d77"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:438.28125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:285.93750rpx;top:140.62500rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u8fd1\u4e09\u4e9a\u6e7e\u8def\u3001\u52a8\u8f66\u7ad9\u3001\u673a\u573a\u3001\u6930\u68a6\u957f\u5eca\u3001\u5e02\u533a\u3001\u5357\u5c71\u5bfa\u3001\u5929\u6daf\u6d77\u89d2\u3001\u897f\u5c9b\u3001\u5927\u4e1c\u6d77\u3002 "}]},"freeVessel7":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:rgb(204, 204, 204) 0px 1px 0px;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:351.56250rpx;","content":[{"type":"picture","style":"width:234.37500rpx;height:187.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:11.71875rpx;opacity:1;left:21.09375rpx;top:30.46875rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292255317.png"},"eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10027\",\"inner_page_link\":\"\\\/pages\\\/page10027\\\/page10027\"}","imgstyle":"height:187.50000rpx"},{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:234.37500rpx;line-height:65.62500rpx;height:65.62500rpx;background:rgb(255, 153, 0);opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;left:21.09375rpx;top:248.43750rpx;","content":"\u67e5\u770b\u8be6\u60c5","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10027\",\"inner_page_link\":\"\\\/pages\\\/page10027\\\/page10027\"}"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:438.28125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:285.93750rpx;top:93.75000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4e09\u4e9a\u5eb7\u5e74\u9152\u5e97\u4f4d\u4e8e\u4e09\u4e9a\u6e7e\u8def\u4e2d\u6bb5\uff0c\u9152\u5e9758\u5e73\u7c73\u6d77\u6d0b\u4e3b\u9898\u5ba2\u623f\u901a\u900f\u5f00\u9614\uff0c\u62e5\u6709\u5b8c\u7f8e\u7684\u4e00\u7ebf\u6d77\u666f\u666f\u89c2\uff0c\u4e09\u4e9a\u6e7e\u7684\u6d69\u701a\u6d77\u666f\u5c3d\u6536\u773c\u5e95\u3002"},{"type":"text","style":"color:#000000;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:246.09375rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:260.15625rpx;top:25.78125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4e09\u4e9a\u5eb7\u5e74\u9152\u5e97"},{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:178.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:557.81250rpx;top:25.78125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u00a51238\u8d77"}]},"freeVessel8":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:rgb(204, 204, 204) 0px 1px 0px;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:351.56250rpx;","content":[{"type":"picture","style":"width:234.37500rpx;height:187.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:11.71875rpx;opacity:1;left:21.09375rpx;top:30.46875rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292259903.jpg"},"eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10026\",\"inner_page_link\":\"\\\/pages\\\/page10026\\\/page10026\"}","imgstyle":"height:187.50000rpx"},{"type":"text","style":"color:#000000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:468.75000rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:257.81250rpx;top:25.78125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u81ea\u7531\u7a7a\u95f4\u6d77\u6ee8\u516c\u5bd3(\u6d77\u82b1\u8def\u5206\u5e97)"},{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:234.37500rpx;line-height:65.62500rpx;height:65.62500rpx;background:rgb(255, 153, 0);opacity:1;border-radius:11.71875rpx;box-shadow:#000000 0px 0px 0px;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;left:21.09375rpx;top:248.43750rpx;","content":"\u67e5\u770b\u8be6\u60c5","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10026\",\"inner_page_link\":\"\\\/pages\\\/page10026\\\/page10026\"}"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:438.28125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:285.93750rpx;top:140.62500rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4e09\u4e9a\u5927\u4e1c\u6d77\u91d1\u8302\u6d77\u666f\u82b1\u56ed \uff0c\u6709\u7f18\u4f4f\u4e0b\u6765\u7684\u670b\u53cb\uff0c\u5e0c\u671b\u5b83\u80fd\u7ed9\u60a8\u5e26\u6765\u8212\u9002\u7684\u65c5\u9014\u4f53\u9a8c\u3002"},{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:145.31250rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:581.25000rpx;top:82.03125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u00a5216\u8d77"}]},"freeVessel9":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:rgb(204, 204, 204) 0px 1px 0px;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:351.56250rpx;","content":[{"type":"picture","style":"width:234.37500rpx;height:187.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:11.71875rpx;opacity:1;left:21.09375rpx;top:30.46875rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292352637.png"},"eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10028\",\"inner_page_link\":\"\\\/pages\\\/page10028\\\/page10028\"}","imgstyle":"height:187.50000rpx"},{"type":"text","style":"color:#000000;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:290.62500rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:253.12500rpx;top:30.46875rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u9047\u89c1\u7231\u6d77\u666f\u516c\u5bd3"},{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:234.37500rpx;line-height:65.62500rpx;height:65.62500rpx;background:rgb(255, 153, 0);opacity:1;border-radius:11.71875rpx;box-shadow:#000000 0px 0px 0px;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;left:21.09375rpx;top:248.43750rpx;","content":"\u67e5\u770b\u8be6\u60c5","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10028\",\"inner_page_link\":\"\\\/pages\\\/page10028\\\/page10028\"}"},{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:140.62500rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:585.93750rpx;top:30.46875rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u00a5188\u8d77"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:438.28125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:285.93750rpx;top:93.75000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6bd7\u90bb\u6d77\u8fb9\uff0c\u95e8\u53e3\u6709\u4e00\u6761\u7f8e\u98df\u8857\uff0c\u6cf0\u56fd\u83dc\u3001\u897f\u9910\u3001\u6d77\u9c9c\u9986\u7b49\uff0c\u53ef\u4ee5\u8ba9\u60a8\u5728\u8fd9\u91cc\u5c3d\u60c5\u7684\u4eab\u53d7\u81ea\u5df1\u7684\u5047\u671f\u751f\u6d3b\u3002"}]},"freeVessel10":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:rgb(204, 204, 204) 0px 1px 0px;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:351.56250rpx;","content":[{"type":"picture","style":"width:234.37500rpx;height:187.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:11.71875rpx;opacity:1;left:21.09375rpx;top:30.46875rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292356575.jpg"},"eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10029\",\"inner_page_link\":\"\\\/pages\\\/page10029\\\/page10029\"}","imgstyle":"height:187.50000rpx"},{"type":"text","style":"color:#000000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:478.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:260.15625rpx;top:30.46875rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u5927\u4e1c\u6d77HOME\u5957\u623f\u5ea6\u5047\u6d77\u666f\u5ba2\u6808"},{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:145.31250rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:592.96875rpx;top:82.03125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u00a578\u8d77"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:438.28125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:285.93750rpx;top:140.62500rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u5ba2\u6808\u5730\u5904\u5927\u4e1c\u6d77\u91d1\u8302\u6d77\u666f\u82b1\u56ed\u5c0f\u533a\uff0c\u8fd1\u6d77\u97f5\u8def\uff0c\u9644\u8fd1\u6709\u5927\u578b\u8d85\u5e02\uff0c\u590f\u65e5\u767e\u8d27\u8d2d\u7269\u4e2d\u5fc3\uff0c\u51fa\u884c\u4fbf\u5229\u3002"},{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:234.37500rpx;line-height:65.62500rpx;height:65.62500rpx;background:rgb(255, 153, 0);opacity:1;border-radius:11.71875rpx;box-shadow:#000000 0px 0px 0px;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;left:21.09375rpx;top:248.43750rpx;","content":"\u67e5\u770b\u8be6\u60c5","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10029\",\"inner_page_link\":\"\\\/pages\\\/page10029\\\/page10029\"}"}]},"freeVessel11":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:rgb(204, 204, 204) 0px 1px 0px;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:351.56250rpx;","content":[{"type":"picture","style":"width:234.37500rpx;height:187.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:11.71875rpx;opacity:1;left:21.09375rpx;top:30.46875rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292377914.jpg"},"eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10030\",\"inner_page_link\":\"\\\/pages\\\/page10030\\\/page10030\"}","imgstyle":"height:187.50000rpx"},{"type":"text","style":"color:#000000;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:250.78125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:257.81250rpx;top:30.46875rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6d6a\u6f2b\u6d77\u666f\u516c\u5bd3"},{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:234.37500rpx;line-height:65.62500rpx;height:65.62500rpx;background:rgb(255, 153, 0);opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;left:21.09375rpx;top:248.43750rpx;","content":"\u67e5\u770b\u8be6\u60c5","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10030\",\"inner_page_link\":\"\\\/pages\\\/page10030\\\/page10030\"}"},{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:140.62500rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:585.93750rpx;top:30.46875rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u00a5104\u8d77"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:438.28125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:285.93750rpx;top:93.75000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6d6a\u6f2b\u6d77\u666f\u516c\u5bd3\u4f4d\u4e8e\u4e09\u4e9a\u4e00\u7ebf\u6d77\u666f\u7684\u9ad8\u6863\u793e\u533a\uff0c\u5176\u72ec\u5177\u4e00\u683c\u7684\u70ed\u5e26\u6d77\u6ee8\u88c5\u4fee\u98ce\u683c\uff0c\u8ba9\u4f60\u611f\u53d7\u5230\u5bb6\u5ead\u5f0f\u4f4f\u5bbf\u7684\u6e29\u99a8\u670d\u52a1\uff01"}]},"picture12":{"type":"picture","style":"width:585.93750rpx;height:35.15625rpx;margin-left:auto;margin-right:auto;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;-webkit-box-sizing:border-box;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292385239.png"},"imgstyle":"height:35.15625rpx"}};
                        return mappDate;
                    }
                    function router(){
                        return "page10006";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "酒店预定";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                