
                    function appData(){
                        var mappDate = {"topNav0":"","album1":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:0px;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293993247.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:0px;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:421.87500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293993247.png\"}"}]},"freeVessel2":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:145.31250rpx;","content":[{"type":"picture","style":"width:140.62500rpx;height:140.62500rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:595.31250rpx;top:0px;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292402831.jpg"},"eventHandler":"bindMap","eventParams":"{\"mapnid\":\"JYKqXM\",\"mapname\":\"\\u9047\\u89c1\\u7231\\u6d77\\u666f\\u516c\\u5bd3\"}","imgstyle":"height:140.62500rpx"},{"type":"text","style":"color:#353535;font-size:28.12500rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:534.37500rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:58.59375rpx;top:75.00000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u5929\u6daf\u533a\u4e09\u4e9a\u6e7e\u8def116\u53f7\u84dd\u8272\u6d77\u5cb8\u5c0f\u533aG\u5ea7"},{"type":"text","style":"color:#000000;font-size:35.15625rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:311.71875rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:4.68750rpx;top:14.06250rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u9047\u89c1\u7231\u6d77\u666f\u516c\u5bd3"},{"type":"picture","style":"width:46.87500rpx;height:46.87500rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:28.12500rpx;top:77.34375rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292408424.png"},"imgstyle":"height:46.87500rpx"}]},"text3":{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:9.37500rpx;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:rgb(255, 153, 0);box-shadow:rgb(255, 153, 0) 0px 1px 2px;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:23.43750rpx;","content":"\u8ba2\u623f\u70ed\u7ebf\uff1a187 8981 9885","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"18789819885\"}"},"text4":{"type":"text","style":"color:#38761d;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:93.75000rpx;background:rgba(0,0,0,0);width:750.00000rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:0px;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6682\u4e0d\u652f\u6301\u5728\u7ebf\u8ba2\u623f\uff0c\u8bf7\u76f4\u63a5\u7535\u8bdd\u9884\u7ea6\uff01"},"title5":{"type":"title","style":"line-height:70.31250rpx;margin-top:14.06250rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(255, 255, 255);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u9152\u5e97\u4ecb\u7ecd","markColor":"rgb(48, 170, 245)","mode":0},"text6":{"type":"text","style":"color:#626262;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:679.68750rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"       \u4e09\u4e9a\u9047\u89c1\u7231\u6d77\u666f\u516c\u5bd3\u4f4d\u4e8e\u4e09\u4e9a\u7684\u9ec4\u91d1\u5730\u6bb5\uff0c\u6bd7\u90bb\u6d77\u8fb9\uff0c\u53ef\u5c3d\u60c5\u73a9\u800d\uff0c\u4e0d\u7528\u62c5\u5fc3\u5929\u9ed1\u800c\u5f52\uff0c\u540c\u65f6\u6bcf\u95f4\u623f\u90fd\u80fd\u4e0d\u540c\u7a0b\u5ea6\u7684\u89c2\u770b\u5230\u5357\u6d77\u98ce\u666f\uff0c\u65e9\u6668\u62c9\u5f00\u7a97\u5e18\uff0c\u6e29\u67d4\u7684\u9633\u5149\u5c04\u8fdb\u623f\u5c4b\uff0c\u6e29\u6696\u60ec\u610f\u3002\n       \u5c0f\u533a\u5c31\u50cf\u4e00\u4e2a\u70ed\u5e26\u96e8\u6797\u516c\u56ed\uff0c\u5145\u5206\u5229\u7528\u4e09\u4e9a\u72ec\u7279\u7684\u5730\u7406\u6761\u4ef6\u548c\u81ea\u7136\u666f\u89c2\uff0c\u5b9c\u5c45\u3001\u5b9c\u517b\u3001\u5b9c\u52a8\u3001\u5b9c\u9759\uff0c\u72ec\u4e00\u65e0\u4e8c\uff0c\u65e0\u53ef\u66ff\u4ee3\u3002\u95e8\u53e3\u6709\u4e00\u6761\u7f8e\u98df\u8857\uff0c\u6cf0\u56fd\u83dc\u3001\u897f\u9910\u3001\u6d77\u9c9c\u9986\u7b49\uff0c\u53ef\u4ee5\u8ba9\u60a8\u5728\u8fd9\u91cc\u5c3d\u60c5\u7684\u4eab\u53d7\u81ea\u5df1\u7684\u5047\u671f\u751f\u6d3b\u3002"},"button7":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:23.43750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u8fd4 \u56de","eventHandler":"tapBack"},"freeVessel8":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:35.15625rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10028";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "遇见爱海景公寓";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                