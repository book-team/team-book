
                    function appData(){
                        var mappDate = {"topNav0":"","album1":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:0px;display:block;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291164333.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10009\",\"inner_page_link\":\"\\\/pages\\\/page10009\\\/page10009\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291167017.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10011\",\"inner_page_link\":\"\\\/pages\\\/page10011\\\/page10011\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291169557.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10010\",\"inner_page_link\":\"\\\/pages\\\/page10010\\\/page10010\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291175214.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10012\",\"inner_page_link\":\"\\\/pages\\\/page10012\\\/page10012\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291172977.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10013\",\"inner_page_link\":\"\\\/pages\\\/page10013\\\/page10013\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291177212.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10014\",\"inner_page_link\":\"\\\/pages\\\/page10014\\\/page10014\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291178658.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10015\",\"inner_page_link\":\"\\\/pages\\\/page10015\\\/page10015\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291180655.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10016\",\"inner_page_link\":\"\\\/pages\\\/page10016\\\/page10016\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291183528.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10017\",\"inner_page_link\":\"\\\/pages\\\/page10017\\\/page10017\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291187377.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10018\",\"inner_page_link\":\"\\\/pages\\\/page10018\\\/page10018\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291190513.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10019\",\"inner_page_link\":\"\\\/pages\\\/page10019\\\/page10019\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291192124.jpg","title":"","li_class":"album-pic","li_style":"margin-left:23.43750rpx;margin-top:18.75000rpx;width:703.12500rpx;border-radius:23.43750rpx;","img_style":"height:304.68750rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#444444;position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10020\",\"inner_page_link\":\"\\\/pages\\\/page10020\\\/page10020\"}"}]},"bottomNav2":"","picture3":{"type":"picture","style":"width:609.37500rpx;height:35.15625rpx;margin-left:auto;margin-right:auto;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;-webkit-box-sizing:border-box;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/15294804592.png"},"imgstyle":"height:35.15625rpx"}};
                        return mappDate;
                    }
                    function router(){
                        return "page10001";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "书架";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                