
                    function appData(){
                        var mappDate = {"topNav0":"","picture1":{"type":"picture","style":"width:1021.87500rpx;height:351.56250rpx;margin-left:auto;margin-right:auto;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;-webkit-box-sizing:border-box;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/15294944926.jpg"},"imgstyle":"height:351.56250rpx"},"title2":{"type":"title","style":"line-height:93.75000rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(255, 255, 255);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u5546\u5bb6\u5165\u9a7b\u7533\u8bf7\uff1a","markColor":"rgb(48, 170, 245)","mode":"1"},"dynamicform3":{"type":"dynamicform","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:#ffffff;","content":[{"type":"singletext","style":"margin-top:0px;margin-left:98.43750rpx;margin-right:auto;opacity:1;border-radius:0px;width:679.68750rpx;height:82.03125rpx;","compId":"data.content[0]","formCompid":"dynamicform3","segment":"form1","isneed":1,"content":"\u8bf7\u8f93\u5165\u60a8\u7684\u59d3\u540d","namestyle":"font-size:30.46875rpx;color:#000000;max-width:31%;height:100%;line-height:82.03125rpx;display:inline-block;float:left;","contentstyle":"font-size:30.46875rpx;color:#000000;border-radius:14.06250rpx;width:67%;height:100%;float:left;margin-left:2%;","textname":"\u59d3\u540d","choosenum":0},{"type":"singletext","style":"margin-top:23.43750rpx;margin-left:98.43750rpx;margin-right:auto;opacity:1;border-radius:0px;width:679.68750rpx;height:82.03125rpx;","compId":"data.content[1]","formCompid":"dynamicform3","segment":"form2","isneed":1,"content":"\u8bf7\u8f93\u5165\u60a8\u7684\u7535\u8bdd","namestyle":"font-size:30.46875rpx;color:#000000;max-width:31%;height:100%;line-height:82.03125rpx;display:inline-block;float:left;","contentstyle":"font-size:30.46875rpx;color:#000000;border-radius:14.06250rpx;width:67%;height:100%;float:left;margin-left:2%;","textname":"\u7535\u8bdd","choosenum":0},{"type":"singletext","style":"margin-top:23.43750rpx;margin-left:auto;margin-right:auto;opacity:1;border-radius:0px;width:679.68750rpx;height:82.03125rpx;","compId":"data.content[2]","formCompid":"dynamicform3","segment":"form3","isneed":1,"content":"\u8bf7\u8f93\u5165\u60a8\u7684\u5e97\u94fa\/\u4f01\u4e1a\u540d\u79f0","namestyle":"font-size:30.46875rpx;color:#000000;max-width:31%;height:100%;line-height:82.03125rpx;display:inline-block;float:left;","contentstyle":"font-size:30.46875rpx;color:#000000;border-radius:14.06250rpx;width:67%;height:100%;float:left;margin-left:2%;","textname":"\u5e97\u94fa\u540d\u79f0","choosenum":0},{"type":"multitext","style":"margin-top:23.43750rpx;margin-left:auto;margin-right:auto;opacity:1;border-radius:0px;width:679.68750rpx;height:187.50000rpx;","compId":"data.content[3]","formCompid":"dynamicform3","segment":"form4","isneed":1,"content":"\u8bf7\u8f93\u5165\u60a8\u7684\u5e97\u94fa\/\u4f01\u4e1a\u5730\u5740","namestyle":"font-size:30.46875rpx;color:#000000;line-height:82.03125rpx;max-width:31%;height:100%;display:inline-block;float:left;","contentstyle":"font-size:30.46875rpx;color:#000000;border-radius:14.06250rpx;width:67%;height:100%;float:left;margin-left:2%;","textname":"\u5e97\u94fa\u5730\u5740","choosenum":0},{"type":"option","style":"margin-top:23.43750rpx;margin-left:93.75000rpx;margin-right:auto;width:679.68750rpx;opacity:1;background:#ffffff;color:#626262;line-height:82.03125rpx;font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;","compId":"data.content[4]","formCompid":"dynamicform3","segment":"form5","isneed":1,"titleStyle":"background:#000000;color:#ffffff;font-size:32.81250rpx;line-height:82.03125rpx;font-weight:normal;font-style:normal;text-decoration:none;","selectAmount":1,"content":{"title":"\u884c\u4e1a","lists":["\u666f\u70b9","\u7f8e\u98df","\u9152\u5e97","\u79df\u8f66","\u5176\u4ed6"]},"namestyle":"font-size:30.46875rpx;color:#000000;line-height:82.03125rpx;height:100%;max-width:31%;display:inline-block;float:left;","contentstyle":"font-size:30.46875rpx;color:#000000;border-radius:0px;height:100%;width:63%;float:left;margin-left:2%;","choosenum":0},{"type":"multitext","style":"margin-top:23.43750rpx;margin-left:auto;margin-right:auto;opacity:1;border-radius:0px;width:679.68750rpx;height:187.50000rpx;","compId":"data.content[5]","formCompid":"dynamicform3","segment":"form6","isneed":1,"content":"\u8bf7\u8f93\u5165\u60a8\u7684\u5165\u9a7b\u7406\u7531","namestyle":"font-size:30.46875rpx;color:#000000;line-height:82.03125rpx;max-width:31%;height:100%;display:inline-block;float:left;","contentstyle":"font-size:30.46875rpx;color:#000000;border-radius:14.06250rpx;width:67%;height:100%;float:left;margin-left:2%;","textname":"\u5165\u9a7b\u7406\u7531","choosenum":0},{"type":"submit","style":"margin-top:46.87500rpx;margin-left:auto;margin-right:auto;width:585.93750rpx;height:82.03125rpx;opacity:1;background:#0da3f9;border-radius:14.06250rpx;font-size:35.15625rpx;color:#ffffff;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;line-height:82.03125rpx;","compId":"data.content[6]","formCompid":"dynamicform3","segment":"","isneed":1,"content":"\u63d0\u4ea4\u7533\u8bf7"}],"form":"ruzhu","compId":"dynamicform3","formCompid":"dynamicform3"},"freeVessel4":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:35.15625rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10032";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "商家入驻申请";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                