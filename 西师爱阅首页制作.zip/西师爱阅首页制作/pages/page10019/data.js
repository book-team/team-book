
                    function appData(){
                        var mappDate = {"topNav0":"","title1":{"type":"title","style":"line-height:93.75000rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(243, 243, 243);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u4e9a\u9a6c\u900a\u4e1b\u6797\u6c34\u4e50\u56ed \u00b7 \u666f\u70b9\u7b80\u4ecb","markColor":"rgb(48, 170, 245)","mode":"1"},"text2":{"type":"text","style":"color:#444444;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"       \u4e9a\u9a6c\u900a\u4e1b\u6797\u6c34\u4e50\u56ed\u5750\u843d\u4e8e\u4e09\u4e9a\u6e7e\u7ea2\u6811\u6797\u5ea6\u5047\u4e16\u754c\uff0c\u5360\u57303.3\u4e07\u5e73\u65b9\u7c73\u3002\u4e50\u56ed\u5185\u8bbe\u6709\u5ca9\u9f9b\u3001\u5ca9\u6d46\u3001\u6e56\u6ee8\u3001\u706b\u5c71\u53ca\u6d8c\u6d6a\u6d6a\u4e94\u4e2a\u4e3b\u9898\u6cf3\u6c60\uff0c\u5e76\u6709\u6bd4\u80a9\u9876\u7ea7\u6c34\u4e0a\u5a31\u4e50\u9879\u76ee\u7684\u73af\u72b6\u7279\u8272\u6f02\u6d41\u6cb3\u3001\u513f\u7ae5\u6c34\u5be8\u3001\u5de8\u517d\u7897\u6ed1\u9053\u3001\u5927\u6c34\u70ae\u3001\u87ba\u65cb\u7ec4\u5408\u6ed1\u9053\u3001\u773c\u955c\u86c7\u6ed1\u9053\u3001\u56db\u5f69\u7ade\u901f\u6ed1\u9053\u3001\u4eba\u9020\u6c99\u6ee9\u53ca\u6c34\u5e55\u7535\u5f71\uff0c\u540c\u65f6\u914d\u5907\u6e56\u7554\u9152\u5427\u3001\u5ca9\u9f9b\u5427\u7b49\u4f11\u95f2\u9910\u5427\u3002\u662f\u5bb6\u4eba\u3001\u670b\u53cb\u4e00\u540c\u4eab\u53d7\u65e0\u9650\u6b22\u4e50\u7684\u6c34\u4e16\u754c\u7684\u53bb\u5904\u3002"},"map3":{"type":"map","style":"width:750.00000rpx;height:351.56250rpx;margin-top:23.43750rpx;margin-left:0px;color:#38761d;font-size:32.81250rpx;text-align:center;font-weight:normal;font-style:normal;text-decoration:none;","showmap":true,"content":"\u6d77\u5357\u7701\u4e09\u4e9a\u5e02\u4e09\u4e9a\u6e7e\u51e4\u51f0\u8def155\u53f7","lat":18.28322,"lng":109.49379,"markers":[{"latitude":18.28322,"longitude":109.49379}],"compid":"map3"},"button4":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:4.68750rpx;opacity:1;border-radius:14.06250rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u5730\u56fe\u5bfc\u822a","eventHandler":"bindMap","eventParams":"{\"mapnid\":\"XrgmoE\",\"mapname\":\"\\u4e9a\\u9a6c\\u900a\\u4e1b\\u6797\\u6c34\\u4e50\\u56ed\"}"},"album5":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:23.43750rpx;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292018545.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292018916.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/21529202008.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/71529201948.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/51529202161.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"}]},"button6":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:23.43750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u8fd4 \u56de","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10001\",\"inner_page_link\":\"\\\/pages\\\/page10001\\\/page10001\"}"}};
                        return mappDate;
                    }
                    function router(){
                        return "page10019";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "亚马逊丛林水乐园";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                