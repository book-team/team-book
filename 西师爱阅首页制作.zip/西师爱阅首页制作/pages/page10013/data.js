
                    function appData(){
                        var mappDate = {"topNav0":"","title1":{"type":"title","style":"line-height:93.75000rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(243, 243, 243);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u4e9a\u9f99\u6e7e\u70ed\u5e26\u5929\u5802\u68ee\u6797\u516c\u56ed \u00b7 \u666f\u70b9\u7b80\u4ecb","markColor":"rgb(48, 170, 245)","mode":"1"},"text2":{"type":"text","style":"color:#444444;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"       \u4e9a\u9f99\u6e7e\u70ed\u5e26\u5929\u5802\u68ee\u6797\u516c\u56ed\u4f4d\u4e8e\u4e09\u4e9a\u5e02\u4e9a\u9f99\u6e7e\u56fd\u5bb6\u65c5\u6e38\u5ea6\u5047\u533a\uff0c\u666f\u533a\u662f\u7535\u5f71\u300a\u975e\u8bda\u52ff\u6270II\u300b\u5728\u6d77\u5357\u7684\u4e3b\u8981\u53d6\u666f\u5730\uff0c\u4e5f\u56e0\u6b64\u800c\u58f0\u540d\u5927\u566a\u3002\u845b\u4f18\u5728\u7535\u5f71\u4e2d\u5bf9\u666f\u533a\u8bc4\u4ef7\uff1a\u9762\u671d\u5927\u6d77\uff0c\u80cc\u9760\u9752\u5c71\uff0c\u56db\u5b63\u82b1\u5f00\u3002\u4f60\u53ef\u4ee5\u770b\u5230\u7535\u5f71\u4e2d\u51fa\u73b0\u8fc7\u7684\u8fc7\u6c5f\u9f99\u7d22\u6865\u4ee5\u53ca\u53eb\u505a\u5ced\u58c1\u5929\u6c60\u7684\u6cf3\u6c60\u7b49\u7b49\u3002\n       \u4f5c\u4e3a\u79bb\u4e09\u4e9a\u5e02\u4e2d\u5fc3\u6700\u8fd1\u7684\u68ee\u6797\u6c27\u5427\uff0c\u8fd9\u91cc\u7684\u6811\u6728\u7e41\u591a\u8302\u5bc6\uff0c\u5145\u6ee1\u4e86\u70ed\u5e26\u98ce\u60c5\uff0c\u56ed\u5185\u6709\u201c\u6811\u4e2d\u4e4b\u738b\u201d\u9ad8\u5c71\u6995\uff0c\u8fd8\u80fd\u770b\u89c1\u85e4\u7af9\u7b49\u70ed\u5e26\u690d\u7269\uff0c\u90fd\u662f\u5c71\u4e2d\u4e0d\u53ef\u9519\u8fc7\u7684\u666f\u89c2\uff0c\u8ba9\u6e38\u5ba2\u975e\u5e38\u65b9\u4fbf\u5730\u4e00\u7779\u4e2d\u56fd\u70ed\u5e26\u96e8\u6797\u666f\u89c2\u3002\n       \u6b64\u5916\uff0c\u6e38\u56ed\u65f6\u8fd8\u53ef\u4ee5\u6b23\u8d4f\u8fdc\u8fd1\u9ad8\u4f4e\u4e0d\u540c\u89d2\u5ea6\u7684\u4e9a\u9f99\u6e7e\u666f\u8272\uff0c\u6709\u66f4\u5bcc\u5c42\u6b21\u611f\u7684\u666f\u6df1\u3002\u722c\u4e0a\u666f\u533a\u6700\u9ad8\u5cf0\uff0c\u8fd8\u53ef\u4ee5\u4ece\u4e0a\u800c\u4e0b\u4fef\u77b0\u4e9a\u9f99\u6e7e\u5168\u666f\uff0c\u770b\u201c\u5929\u4e0b\u7b2c\u4e00\u6d77\u666f\u201d\u3002"},"map3":{"type":"map","style":"width:750.00000rpx;height:351.56250rpx;margin-top:23.43750rpx;margin-left:0px;color:#38761d;font-size:30.46875rpx;text-align:center;font-weight:normal;font-style:normal;text-decoration:none;","showmap":true,"content":"\u4e09\u4e9a\u5e02\u5409\u9633\u533a\u4e9a\u9f99\u6e7e\u56fd\u5bb6\u65c5\u6e38\u5ea6\u5047\u533a\u5185","lat":18.24898,"lng":109.625229,"markers":[{"latitude":18.24898,"longitude":109.625229}],"compid":"map3"},"button4":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:4.68750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u5730\u56fe\u5bfc\u822a","eventHandler":"bindMap","eventParams":"{\"mapnid\":\"BSZDeu\",\"mapname\":\"\\u4e9a\\u9f99\\u6e7e\\u70ed\\u5e26\\u5929\\u5802\\u68ee\\u6797\\u516c\\u56ed\"}"},"album5":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:23.43750rpx;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/31529139615.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/21529139702.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/91529139730.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/11529139756.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/15291398007.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"}]},"button6":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:23.43750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u8fd4 \u56de","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10001\",\"inner_page_link\":\"\\\/pages\\\/page10001\\\/page10001\"}"},"freeVessel7":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:35.15625rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10013";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "亚龙湾热带天堂森林公园";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                