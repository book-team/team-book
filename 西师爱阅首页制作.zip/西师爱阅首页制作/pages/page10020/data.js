
                    function appData(){
                        var mappDate = {"topNav0":"","title1":{"type":"title","style":"line-height:93.75000rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(243, 243, 243);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u7b2c\u4e00\u5e02\u573a \u00b7 \u666f\u70b9\u7b80\u4ecb","markColor":"rgb(48, 170, 245)","mode":"1"},"text2":{"type":"text","style":"color:#444444;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"       \u4e09\u4e9a\u7b2c\u4e00\u96c6\u8d38\u5e02\u573a\u662f\u4e09\u4e9a\u6700\u5927\u4e14\u4ea7\u54c1\u6700\u9f50\u5168\u7684\u519c\u8d38\u5e02\u573a\uff0c\u5403\u7684\u3001\u7528\u7684\u3001\u4f4f\u7684\u4e00\u5e94\u4ff1\u5168\u3002\u5bf9\u4e8e\u6e38\u5ba2\u800c\u8a00\u8fd9\u91cc\u70ed\u5e26\u6c34\u679c\u3001\u6d77\u9c9c\u54c1\u79cd\u7e41\u591a\uff0c\u4ef7\u683c\u516c\u9053\uff0c\u662f\u8d2d\u4e70\u6d77\u5357\u7279\u7684\u597d\u53bb\u5904\u3002\u665a\u95f4\u7684\u591c\u5e02\u6709\u70e7\u70e4\u3001\u6e05\u8865\u51c9\u7b49\u5c0f\u5403\u8ba9\u4eba\u5927\u9971\u53e3\u798f\u3002\n       \u4e09\u4e9a\u7b2c\u4e00\u5e02\u573a\u5c31\u662f\u6311\u9009\u6d77\u9c9c\u548c\u6c34\u679c\u7684\u9996\u9009\u5730\u70b9\uff0c\u4ef7\u683c\u516c\u9053\u54c1\u79cd\u591a\u6837\u3002\u8fd9\u91cc\u662f\u4e09\u4e9a\u4eba\u6c14\u6700\u65fa\u7684\u5546\u4e1a\u533a\uff0c\u957f\u8fbe600\u591a\u7c73\u8d2d\u7269\u4e00\u6761\u8857\u62e5\u6709\u6d77\u5357\u6c34\u679c\u3001\u6d77\u9c9c\u3001\u6d77\u5357\u5f53\u5730\u52b3\u52a8\u5de5\u5177\u3001\u4e09\u4e9a\u7279\u8272\u5c0f\u5403\u7b49\u3002\u65e0\u8bba\u662f\u521d\u5230\u6d77\u5357\u60f3\u54c1\u5c1d\u6d77\u5473\u8fd8\u662f\u4e34\u8d70\u60f3\u5e26\u7eaa\u5ff5\u54c1\uff0c\u4e09\u4e9a\u7b2c\u4e00\u5e02\u573a\u90fd\u662f\u6781\u529b\u63a8\u8350\u7684\u5730\u65b9\uff01\n       \u5e02\u573a\u4e3b\u8981\u5206\u4e3a\u4e8c\u5c42\uff0c\u4e00\u5c42\u662f\u4e3b\u8981\u4ee5\u519c\u526f\u4ea7\u54c1\uff0c\u6d77\u4ea7\u9c7c\u7c7b\uff0c\u8089\u7c7b\uff0c\u74dc\u679c\u852c\u83dc\u4e3a\u4e3b\uff0c\u6d77\u5357\u672c\u5730\u571f\u7279\u4ea7\u4e5f\u4e0d\u5c11\uff0c\u6709\u5404\u79cd\u9c7c\u5e72\u3001\u6d77\u53c2\u3001\u6d77\u86c7\u5e72\u3001\u9c7c\u7fc5\u3001\u5e72\u9c7f\u3001\u8d1d\u7c7b\u3001\u867e\u4ec1\u3001\u9c8d\u9c7c\u7b49\uff0c\u8fd8\u6709\u4e00\u4e9b\u70ed\u5e26\u5e72\u679c\uff0c\u5982\u8354\u679d\u5e72\u3001\u8170\u679c\u4ec1\u3001\u80e1\u6912\u7b49\u4ea7\u54c1\u3002\u4e8c\u5c42\u662f\u4ee5\u5356\u670d\u88c5\u978b\u5e3d\u4e3a\u4e3b\u3002\u665a\u95f4\u7b2c\u4e00\u5e02\u573a\u6240\u8fd8\u6709\u591c\u5e02\uff0c\u5f53\u7136\u4ef7\u683c\u66f4\u662f\u4f4e\u5f97\u4ee4\u4eba\u5403\u60ca\uff0c\u4e0d\u8fc7\u524d\u63d0\u5c31\u662f\u4f60\u4f1a\u780d\u4ef7\uff01"},"map3":{"type":"map","style":"width:750.00000rpx;height:351.56250rpx;margin-top:23.43750rpx;margin-left:0px;color:#38761d;font-size:30.46875rpx;text-align:center;font-weight:normal;font-style:normal;text-decoration:none;","showmap":true,"content":"\u6d77\u5357\u7701\u4e09\u4e9a\u5e02\u5409\u9633\u533a\u65b0\u5efa\u8857155\u53f7","lat":18.23826,"lng":109.50873,"markers":[{"latitude":18.23826,"longitude":109.50873}],"compid":"map3"},"button4":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:4.68750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u5730\u56fe\u5bfc\u822a","eventHandler":"bindMap","eventParams":"{\"mapnid\":\"endkJk\",\"mapname\":\"\\u7b2c\\u4e00\\u5e02\\u573a\"}"},"album5":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:23.43750rpx;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/81529202791.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/101529202853.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/81529202870.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/11529202900.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/51529202936.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"}]},"title6":{"type":"title","style":"line-height:70.31250rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(243, 243, 243);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u7279\u522b\u63d0\u9192","markColor":"rgb(48, 170, 245)","mode":"1"},"text7":{"type":"text","style":"color:#444444;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u7b2c\u4e00\u5e02\u573a\u7684\u4eba\u6d41\u91cf\u76f8\u5f53\u5927\uff0c\u5c24\u5176\u662f\u8282\u5047\u65e5\uff0c\u56e0\u6b64\u5c0f\u5077\u4e5f\u5f88\u591a\uff0c\u52a1\u5fc5\u6ce8\u610f\u968f\u8eab\u8d22\u7269\uff0c\u4ee5\u514d\u88ab\u76d7\u3002"},"button8":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:23.43750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u8fd4 \u56de","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10001\",\"inner_page_link\":\"\\\/pages\\\/page10001\\\/page10001\"}"},"freeVessel9":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:35.15625rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10020";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "第一市场";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                