
                    function appData(){
                        var mappDate = {"topNav0":"","text1":{"type":"text","style":"color:#000000;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:23.43750rpx;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"      \u4e3a\u4e86\u66f4\u597d\u53d1\u6325\u793e\u4f1a\u76d1\u7763\u3001\u5a92\u4f53\u76d1\u7763\u7684\u4f5c\u7528\uff0c\u4e09\u4e9a\u65c5\u6e38\u6307\u5357\u5c06\u9762\u5411\u793e\u4f1a\u5f81\u96c6\u6d77\u5357\u65c5\u6e38\u670d\u52a1\u8d28\u91cf\u4e49\u52a1\u76d1\u7763\u5458\uff0c\u4ee5\u671f\u52a9\u529b\u6d77\u5357\u65c5\u6e38\u670d\u52a1\u8d28\u91cf\u63d0\u5347\uff0c\u52a0\u5feb\u56fd\u9645\u65c5\u6e38\u5c9b\u53d1\u5c55\u3002"},"picture2":{"type":"picture","style":"width:703.12500rpx;height:164.06250rpx;margin-left:auto;margin-right:auto;margin-top:18.75000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:23.43750rpx;opacity:1;-webkit-box-sizing:border-box;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/15294842367.png"},"imgstyle":"height:164.06250rpx"},"title3":{"type":"title","style":"line-height:117.18750rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(255, 255, 255);color:#ff0000;text-align:left;font-size:35.15625rpx;","content":"\u4e09\u4e9a\u65c5\u6e38\u5c40\u6295\u8bc9\u7535\u8bdd\uff1a","markColor":"#ff0000","mode":"1"},"freeVessel4":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:897.65625rpx;","content":[{"type":"text","style":"color:#990000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:548.43750rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:solid;border-width:0px;border-color:rgb(204, 0, 0);box-shadow:rgb(153, 153, 153) 0px 0px 3px;left:100.78125rpx;top:18.75000rpx;-webkit-box-sizing:border-box;border-radius:11.71875rpx;","content":"\u4e09\u4e9a\u65c5\u6e38\u6295\u8bc9\u4e2d\u5fc3\uff1a0898-12301","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089812301\"}"},{"type":"text","style":"color:#990000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:548.43750rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:rgb(153, 153, 153) 0px 0px 3px;left:100.78125rpx;top:117.18750rpx;-webkit-box-sizing:border-box;border-radius:11.71875rpx;","content":"\u4e09\u4e9a\u653f\u5e9c\u670d\u52a1\u70ed\u7ebf\uff1a0898-12345","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089812345\"}"},{"type":"text","style":"color:#990000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:550.78125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:rgb(153, 153, 153) 0px 0px 3px;left:99.60938rpx;top:215.62500rpx;-webkit-box-sizing:border-box;border-radius:11.71875rpx;","content":"\u4e09\u4e9a\u5de5\u5546\u6295\u8bc9\u7535\u8bdd\uff1a0898-12315","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089812315\"}"},{"type":"text","style":"color:#990000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:604.68750rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:rgb(153, 153, 153) 0px 0px 3px;left:72.65625rpx;top:314.06250rpx;-webkit-box-sizing:border-box;border-radius:11.71875rpx;","content":"\u6d77\u53e3\u5e02\u65c5\u6e38\u8d28\u76d1\u6240\uff1a0898-66250780","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089866250780\"}"},{"type":"text","style":"color:#990000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:604.68750rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:rgb(153, 153, 153) 0px 0px 3px;left:72.65625rpx;top:412.50000rpx;-webkit-box-sizing:border-box;border-radius:11.71875rpx;","content":"\u65c5\u6e38\u4ef7\u683c\u6295\u8bc9\u70ed\u7ebf\uff1a0898-65312358","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089865312358\"}"},{"type":"text","style":"color:#990000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:546.09375rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:rgb(153, 153, 153) 0px 0px 3px;left:101.95312rpx;top:510.93750rpx;-webkit-box-sizing:border-box;border-radius:11.71875rpx;","content":"\u6587\u5316\u5e02\u573a\u6295\u8bc9\u7535\u8bdd\uff1a0898-12318","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089812318\"}"},{"type":"text","style":"color:#990000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:578.90625rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:rgb(153, 153, 153) 0px 0px 3px;left:85.54688rpx;top:707.81250rpx;-webkit-box-sizing:border-box;border-radius:11.71875rpx;","content":"\u98df\u54c1\u836f\u54c1\u76d1\u7763\u7ba1\u7406\u5c40\uff1a0898-12331","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089812331\"}"},{"type":"text","style":"color:#990000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:569.53125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:rgb(153, 153, 153) 0px 0px 3px;left:90.23438rpx;top:609.37500rpx;-webkit-box-sizing:border-box;border-radius:11.71875rpx;","content":"\u51fa\u79df\u8f66\u6295\u8bc9\u7535\u8bdd\uff1a0898-66224866","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089866224866\"}"},{"type":"text","style":"color:#ff0000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:689.06250rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:30.46875rpx;top:813.28125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"*\u8bf7\u6295\u8bc9\u4eba\u786e\u4fdd\u6295\u8bc9\u4fe1\u606f\u7684\u5ba2\u89c2\uff0c\u771f\u5b9e\u3001\u51c6\u786e"}]},"share5":{"type":"share","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:0px;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":{"text":"\u5206\u4eab","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/share.png"},"iconStyle":"width:42.18750rpx;height:42.18750rpx;"},"freeVessel6":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:28.12500rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10008";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "帮助中心";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                