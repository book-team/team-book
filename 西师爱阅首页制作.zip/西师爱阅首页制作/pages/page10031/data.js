
                    function appData(){
                        var mappDate = {"topNav0":"","album1":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:0px;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15294014581.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15294014581.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15294014698.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15294014698.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15294014789.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15294014789.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15294014882.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15294014882.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15294015003.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15294015003.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15294016015.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15294016015.png\"}"}]},"freeVessel2":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:145.31250rpx;","content":[{"type":"picture","style":"width:140.62500rpx;height:140.62500rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:595.31250rpx;top:0px;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292402831.jpg"},"eventHandler":"bindMap","eventParams":"{\"mapnid\":\"Yiombq\",\"mapname\":\"\\u5c71\\u6d77\\u5929\\u4e07\\u8c6a\\u9152\\u5e97\"}","imgstyle":"height:140.62500rpx"},{"type":"text","style":"color:#353535;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:487.50000rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:56.25000rpx;top:75.00000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4e09\u4e9a\u5e02\u5409\u9633\u533a\u5927\u4e1c\u6d77\u6d77\u97f5\u8def88\u53f7"},{"type":"text","style":"color:#000000;font-size:35.15625rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:295.31250rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:9.37500rpx;top:14.06250rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u5c71\u6d77\u5929\u4e07\u8c6a\u9152\u5e97"},{"type":"picture","style":"width:46.87500rpx;height:46.87500rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:28.12500rpx;top:77.34375rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292408424.png"},"imgstyle":"height:46.87500rpx"}]},"text3":{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:9.37500rpx;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:rgb(255, 153, 0);box-shadow:rgb(255, 153, 0) 0px 1px 2px;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:23.43750rpx;","content":"\u8ba2\u623f\u70ed\u7ebf\uff1a0898-88211688","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089888211688\"}"},"text4":{"type":"text","style":"color:#38761d;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:93.75000rpx;background:rgba(0,0,0,0);width:750.00000rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:0px;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6682\u4e0d\u652f\u6301\u5728\u7ebf\u8ba2\u623f\uff0c\u8bf7\u76f4\u63a5\u7535\u8bdd\u9884\u7ea6\uff01"},"title5":{"type":"title","style":"line-height:70.31250rpx;margin-top:14.06250rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(255, 255, 255);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u9152\u5e97\u4ecb\u7ecd","markColor":"rgb(48, 170, 245)","mode":0},"text6":{"type":"text","style":"color:#626262;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:679.68750rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"       \u4e09\u4e9a\u5c71\u6d77\u5929\u4e07\u8c6a\u9152\u5e97\u4f4d\u4e8e\u5927\u4e1c\u6d77\u6d77\u97f5\u8def\uff0c\u5468\u8fb9\u7fa4\u5c71\u73af\u7ed5\uff0c\u70ed\u5e26\u690d\u7269\u90c1\u90c1\u8471\u8471\uff0c\u5750\u62e5\u58ee\u4e3d\u7684\u5c71\u5ce6\u548c\u6d77\u6d0b\u7f8e\u666f\uff0c\u66f4\u53ef\u6b23\u8d4f\u5230\u552f\u7f8e\u7684\u65e5\u51fa\u666f\u89c2\u3002\u9152\u5e97\u5730\u7406\u4f4d\u7f6e\u5f97\u5929\u72ec\u539a\uff0c\u9a71\u8f66\u7ea65\u5206\u949f\u5373\u53ef\u8fbe\u5e02\u4e2d\u5fc3\u3002\n\u3000\u3000\u9152\u5e97\u8bbe\u6709\u56db\u767e\u4f59\u95f4\u5bbd\u655e\u8212\u9002\u7684\u5ba2\u623f\u53ca\u5957\u95f4\uff0c\u53ef\u4e00\u89c8\u5927\u4e1c\u6d77\u6e7e\u53ca\u70ed\u5e26\u68ee\u6797\u8986\u76d6\u7684\u7fa4\u5c71\u666f\u81f4\u3002\u9152\u5e97\u4f1a\u8bae\u8bbe\u65bd\u8bbe\u5907\u9f50\u5168\uff0c\u4f1a\u8bae\u533a\u57df\u9762\u79ef\u8fbe4,000\u5e73\u65b9\u7c73\uff0c\u5176\u4e2d\u5305\u62ec\u4e00\u4e2a916\u5e73\u65b9\u7c73\u7684\u5927\u5bb4\u4f1a\u5385\u30011000\u5e73\u65b9\u7c73\u7684\u6d77\u6ee8\u8349\u576a\u3001\u5a5a\u793c\u5802\u53ca\u591a\u4e2a\u5c0f\u578b\u4f1a\u8bae\u5385\u548c\u591a\u529f\u80fd\u5385\u3002\n\u3000\u3000\u9152\u5e97\u62e5\u6709\u5305\u62ec\u4e2d\u9910\u3001\u897f\u9910\u53ca\u97e9\u65e5\u5f0f\u9910\u5385\u5728\u5185\u7684\u4e09\u95f4\u9910\u5385\uff0c\u5305\u542b\u884c\u653f\u9152\u5eca\u5728\u5185\u7684\u56db\u95f4\u9152\u5427\u9152\u5eca\uff0c\u4e00\u95f4\u70d8\u7119\u5e97\u548c\u4e00\u95f4\u9178\u5976\u5c4b\uff0c\u53ef\u4e3a\u5bbe\u5ba2\u63d0\u4f9b\u4e30\u5bcc\u7684\u73af\u7403\u9910\u996e\u4f53\u9a8c\u300224\u5c0f\u65f6\u5f00\u653e\u7684\u6d77\u666f\u5065\u8eab\u623f\u3001\u53f0\u7403\u5ba4\u3001QUAN\u6c34\u7597\u4e2d\u5fc3\u7b49\u4e3a\u5bbe\u5ba2\u63d0\u4f9b\u8212\u9002\u7684\u4f11\u95f2\u5a31\u4e50\u4f53\u9a8c\u3002\n\u3000\u3000\u6b64\u5916\uff0c\u9152\u5e97\u8fd8\u8bbe\u6709\u591a\u4e2a\u5ba4\u5916\u6cf3\u6c60\u53ca\u4e00\u4e2a\u9762\u79ef\u8fbe900\u5e73\u65b9\u7c73\u7684\u8d85\u5927\u513f\u7ae5\u4ff1\u4e50\u90e8\uff0c\u53ef\u4ee4\u5168\u5bb6\u5c3d\u4eab\u65e0\u7a77\u4e50\u8da3\u3002\u65e0\u8bba\u662f\u5546\u52a1\u4e4b\u65c5\u6216\u4f11\u95f2\u65c5\u884c\uff0c\u9152\u5e97\u90fd\u662f\u60a8\u7684\u7406\u60f3\u4e0b\u69bb\u4e4b\u9009\uff0c\u8ba9\u60a8\u5c3d\u4eab\u8212\u9002\u3001\u65c5\u83b7\u7cbe\u5f69\u3002"},"button7":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:23.43750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u8fd4 \u56de","eventHandler":"tapBack"},"freeVessel8":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:35.15625rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10031";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "山海天万豪酒店";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                