
                    function appData(){
                        var mappDate = {"topNav0":"","text1":{"type":"text","style":"color:#ff9900;font-size:35.15625rpx;text-align:center;max-width:100%;line-height:93.75000rpx;background:rgba(0,0,0,0);width:750.00000rpx;font-weight:bold;font-style:normal;text-decoration:none;margin-top:0px;margin-left:0px;margin-right:auto;border-style:none;border-width:0px;border-color:rgb(255, 153, 0);box-shadow:rgb(255, 153, 0) 0px 1px 5px;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:23.43750rpx;","content":"\u4e09\u4e9a\u79df\u8f66\u670d\u52a1 \u00b7 \u552f\u81ea\u9a7e \u00b7 \u4eab\u81ea\u7531"},"text2":{"type":"text","style":"color:#38761d;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:70.31250rpx;background:rgba(0,0,0,0);width:750.00000rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:0px;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"\uff08\u514d\u8d39\u9001\u8f66\u4e0a\u95e8\uff0c\u4e00\u5929150\u5143\u8d77\uff0c\u65b0\u5ba2\u7acb\u51cf\uff09"},"picture3":{"type":"picture","style":"width:750.00000rpx;height:468.75000rpx;margin-left:auto;margin-right:auto;margin-top:7.03125rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;-webkit-box-sizing:border-box;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/81529497222.jpg"},"imgstyle":"height:468.75000rpx"},"title4":{"type":"title","style":"line-height:70.31250rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(255, 255, 255);color:#000000;text-align:left;font-size:32.81250rpx;","content":"\u79df\u8f66\u6d41\u7a0b\uff1a","markColor":"rgb(255, 153, 0)","mode":"1"},"text5":{"type":"text","style":"color:#444444;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u7535\u8bdd\u9884\u8ba2\u3001\u9884\u8ba2\u6210\u529f\u540e\u77ed\u4fe1\u786e\u8ba4\u2192\u7ea6\u5b9a\u65f6\u95f4\u3001\u5730\u70b9\u9001\u8f66\u2192\u627f\u79df\u5165\u51fa\u793a\u8981\u6c42\u7684\u8bc1\u4ef6\u53ca\u590d\u5370\u4ef6\u3001\u767b\u8bb0\u8d44\u6599\u2192\u9a8c\u8f66\/\u652f\u4ed8\u8d39\u7528\u2192\u5728\u79df\u8f66\u5408\u540c\u4e0a\u7b7e\u5b57\u2192\u63d0\u8f66\u3001\u5f00\u59cb\u6109\u5feb\u7684\u65c5\u7a0b\u3002"},"dividing6":{"type":"dividing","style":"border-bottom-color:rgb(229, 229, 229);width:750.00000rpx;border-width:2.34375rpx;margin-top:14.06250rpx;margin-left:0px;margin-right:0px;border-bottom-style:solid;","content":""},"freeVessel7":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:215.62500rpx;","content":[{"type":"text","style":"color:#000000;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:314.06250rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:210.93750rpx;top:23.43750rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u5357\u5c71\u4f70\u4ebf\u6c7d\u8f66\u79df\u51ed"},{"type":"picture","style":"width:187.50000rpx;height:93.75000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:18.75000rpx;top:32.81250rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/15294608499.png"},"imgstyle":"height:93.75000rpx"},{"type":"text","style":"color:#ff0000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:405.46875rpx;font-weight:normal;font-style:normal;text-decoration:underline;border-style:solid;border-width:0px;border-color:rgb(204, 204, 204);box-shadow:rgb(204, 204, 204) 0px 0px 0px;left:210.93750rpx;top:75.00000rpx;-webkit-box-sizing:border-box;border-radius:11.71875rpx;","content":"\u79df\u8f66\u70ed\u7ebf\uff1a400-1727-899","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"4001727899\"}"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:656.25000rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:23.43750rpx;top:138.28125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u5730\u5740\uff1a\u6d77\u53e3\u5e02\u6d77\u79c0\u4e2d\u8def52-6\u53f7\u660c\u6d77\u5546\u52a1\u5927\u53a610\u697c"}]},"freeVessel8":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:234.37500rpx;","content":[{"type":"text","style":"color:#000000;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:285.93750rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:208.59375rpx;top:30.46875rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u946b\u987a\u8fbe\u6c7d\u8f66\u79df\u8d41"},{"type":"picture","style":"width:187.50000rpx;height:117.18750rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:18.75000rpx;top:32.81250rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/15294609171.png"},"imgstyle":"height:117.18750rpx"},{"type":"text","style":"color:#ff0000;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:431.25000rpx;font-weight:normal;font-style:normal;text-decoration:underline;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:210.93750rpx;top:86.71875rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u79df\u8f66\u70ed\u7ebf\uff1a0898-66664111","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089866664111\"}"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:569.53125rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:23.43750rpx;top:159.37500rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u5730\u5740\uff1a\u4e09\u4e9a\u5e02\u6cb3\u4e1c\u533a\u7965\u745e\u8def30-3\u94fa\u9762"}]},"freeVessel9":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:210.93750rpx;","content":[{"type":"picture","style":"width:187.50000rpx;height:82.03125rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:18.75000rpx;top:32.81250rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/101529462819.png"},"imgstyle":"height:82.03125rpx"},{"type":"text","style":"color:#000000;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:187.50000rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:208.59375rpx;top:21.09375rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6d77\u4eae\u79df\u8f66"},{"type":"text","style":"color:#626262;font-size:28.12500rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:527.34375rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:23.43750rpx;top:131.25000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u5730\u5740: \u4e09\u4e9a\u5e02\u51e4\u51f0\u8def\u51ef\u4e30\u5927\u9152\u5e97"},{"type":"text","style":"color:#ff0000;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:445.31250rpx;font-weight:normal;font-style:normal;text-decoration:underline;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:236.71875rpx;top:72.65625rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u79df\u8f66\u70ed\u7ebf\uff1a400-678-3003","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"4006783003\"}"}]},"picture10":{"type":"picture","style":"width:499.21875rpx;height:28.12500rpx;margin-left:auto;margin-right:auto;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;-webkit-box-sizing:border-box;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/15294812265.png"},"imgstyle":"height:28.12500rpx"}};
                        return mappDate;
                    }
                    function router(){
                        return "page10007";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "租车服务";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                