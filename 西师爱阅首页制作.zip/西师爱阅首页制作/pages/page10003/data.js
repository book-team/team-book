
                    function appData(){
                        var mappDate = {"topNav0":"","newpersonal1":{"type":"newpersonal","style":"opacity:1;margin-top:0px;font-weight:normal;font-style:normal;font-size:35.15625rpx;color:#0b5394;text-align:left;position:relative;display:block;","content":[{"text":"\u4e2a\u4eba\u4fe1\u606f","pic":"icon-gerenxinxi","routerlink":"\/peronaldetails","choose":true,"showSec":false,"second":[]},{"text":"\u6536\u8d27\u5730\u5740","pic":"icon-address","routerlink":"\/addressmanage","choose":true,"showSec":false,"second":[]},{"text":"\u79ef\u5206\u5546\u57ce","pic":"icon-jifen","routerlink":"\/integralall","choose":false,"showSec":false,"second":[]},{"text":"\u4f18\u60e0\u5238","pic":"icon-youhuiquan1","routerlink":"\/newCoupon","choose":true,"showSec":false,"second":[]},{"text":"\u4f1a\u5458\u5361","pic":"icon-cardicon2","routerlink":"\/newMember","choose":false,"showSec":false,"second":[]},{"text":"\u7535\u5546\u8d2d\u7269\u8f66","pic":"icon-shopcar","routerlink":"\/shoppingcart","choose":false,"showSec":false,"second":[]},{"text":"\u5fae\u5546\u57ce","pic":"icon-shangdian","routerlink":"","choose":false,"showSec":true,"second":[{"text":"\u6211\u7684\u8ba2\u5355","pic":"icon-rightarrow","routerlink":"\/commodityAllorder","choose":true}]},{"text":"\u62fc\u56e2\u4e2d\u5fc3","pic":"icon-pintuanliucheng4","routerlink":"","choose":false,"showSec":true,"second":[{"text":"\u8ba2\u5355\u5217\u8868","pic":"icon-rightarrow","routerlink":"\/groupgoodsAllorder","choose":true},{"text":"\u56e2\u957f\u4f63\u91d1","pic":"icon-rightarrow","routerlink":"\/groupDeposit","choose":true}]},{"text":"\u5206\u9500\u4e2d\u5fc3","pic":"icon-fenxiao","routerlink":"","choose":false,"showSec":true,"second":[{"text":"\u4e2a\u4eba\u8ba2\u5355","pic":"icon-rightarrow","routerlink":"\/mydisOrder","choose":true},{"text":"\u6211\u7684\u4f63\u91d1","pic":"icon-rightarrow","routerlink":"\/myDeposit","choose":true},{"text":"\u5206\u9500\u8ba2\u5355","pic":"icon-rightarrow","routerlink":"\/disorder","choose":true},{"text":"\u5206\u9500\u4ea7\u54c1","pic":"icon-rightarrow","routerlink":"\/disProduct","choose":true},{"text":"\u4e0b\u7ea7\u6210\u5458","pic":"icon-rightarrow","routerlink":"\/lower_member","choose":true},{"text":"\u6211\u8981\u5206\u9500","pic":"icon-rightarrow","routerlink":"\/iWantDis","choose":true}]},{"text":"\u79d2\u6740\u4e2d\u5fc3","pic":"icon-miaosha","routerlink":"","choose":false,"showSec":true,"second":[{"text":"\u6211\u7684\u8ba2\u5355","pic":"icon-rightarrow","routerlink":"\/myseckOrder","choose":true}]},{"text":"\u5fae\u9910\u996e","pic":"icon-canyin1","routerlink":"","choose":false,"showSec":true,"second":[{"text":"\u5230\u5e97\u8ba2\u5355","pic":"icon-rightarrow","routerlink":"\/takeoutorder\/1","choose":true},{"text":"\u9884\u7ea6\u8ba2\u5355","pic":"icon-rightarrow","routerlink":"\/takeoutorder\/3","choose":true},{"text":"\u81ea\u53d6\u8ba2\u5355","pic":"icon-rightarrow","routerlink":"\/takeoutorder\/2","choose":true},{"text":"\u5916\u9001\u8ba2\u5355","pic":"icon-rightarrow","routerlink":"\/takeoutorder\/0","choose":true}]},{"text":"\u5fae\u540c\u57ce","pic":"icon-loufang","routerlink":"","choose":false,"showSec":true,"second":[{"text":"\u6211\u7684\u8ba2\u5355","pic":"icon-rightarrow","routerlink":"\/commodityAllorder","choose":false},{"text":"\u6211\u53d1\u5e03\u7684","pic":"icon-rightarrow","routerlink":"\/citywide\/0","choose":true},{"text":"\u6211\u7684\u8bc4\u8bba","pic":"icon-rightarrow","routerlink":"\/citywide\/1","choose":true},{"text":"\u56de\u590d\u6211\u7684","pic":"icon-rightarrow","routerlink":"\/citywide\/2","choose":true},{"text":"\u6253\u8d4f\u7ba1\u7406","pic":"icon-rightarrow","routerlink":"\/rewardManage","choose":false}]},{"text":"\u5fae\u9884\u7ea6","pic":"icon-yuyue3","routerlink":"","choose":false,"showSec":true,"second":[{"text":"\u6211\u7684\u9884\u7ea6","pic":"icon-rightarrow","routerlink":"\/bespeaklist","choose":true}]},{"text":"\u6211\u7684\u780d\u4ef7","pic":"icon-kanjia","routerlink":"","choose":false,"showSec":true,"second":[{"text":"\u780d\u4ef7\u8bb0\u5f55","pic":"icon-rightarrow","routerlink":"\/haggleList","choose":true},{"text":"\u780d\u4ef7\u8ba2\u5355","pic":"icon-rightarrow","routerlink":"\/haggleOrder","choose":true}]},{"text":"\u5e97\u94fa\u7ba1\u7406","pic":"icon-shangjiaruzhu","routerlink":"\/sellerJoin","choose":false,"showSec":false,"second":[]},{"text":"\u79ef\u5206\u7b7e\u5230","choose":true,"showSec":false,"second":[]},{"text":"\u6d88\u606f\u5217\u8868","pic":"icon-iconset0336","routerlink":"\/myMessage","choose":true,"showSec":false,"second":[]}],"namestyle":"text-decoration:none;","piccontent":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180623\/15297380896.jpg"},"themeColor":"rgb(255, 0, 0)","compid":"newpersonal1"},"freeVessel2":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:rgb(204, 204, 204) 0px 0px 0px;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:110.15625rpx;","content":[{"type":"picture","style":"width:49.21875rpx;height:49.21875rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:30.46875rpx;top:30.46875rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/15294819393.png"},"imgstyle":"height:49.21875rpx"},{"type":"picture","style":"width:37.50000rpx;height:37.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:689.06250rpx;top:35.15625rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/15294820407.png"},"imgstyle":"height:37.50000rpx"},{"type":"text","style":"color:#626262;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:178.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:65.62500rpx;top:28.12500rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u8054\u7cfb\u6211\u4eec","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"18650073885\"}"}],"eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"18650073885\"}"},"bottomNav3":"","dividing4":{"type":"dividing","style":"border-bottom-color:rgb(238, 238, 238);width:750.00000rpx;border-width:2.34375rpx;margin-top:2.34375rpx;margin-left:0px;margin-right:0px;border-bottom-style:solid;","content":""},"freeVessel5":{"type":"freeVessel","style":"margin-top:2.34375rpx;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:110.15625rpx;","content":[{"type":"picture","style":"width:44.53125rpx;height:44.53125rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:32.81250rpx;top:30.46875rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/71529493908.png"},"imgstyle":"height:44.53125rpx"},{"type":"text","style":"color:#626262;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:187.50000rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:60.93750rpx;top:25.78125rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u5546\u5bb6\u5165\u9a7b"},{"type":"picture","style":"width:37.50000rpx;height:37.50000rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:689.06250rpx;top:35.15625rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/15294939906.png"},"imgstyle":"height:37.50000rpx"}],"eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10032\",\"inner_page_link\":\"\\\/pages\\\/page10032\\\/page10032\"}"},"dividing6":{"type":"dividing","style":"border-bottom-color:rgb(238, 238, 238);width:750.00000rpx;border-width:2.34375rpx;margin-top:2.34375rpx;margin-left:0px;margin-right:0px;border-bottom-style:solid;","content":""},"picture7":{"type":"picture","style":"width:585.93750rpx;height:32.81250rpx;margin-left:auto;margin-right:auto;margin-top:46.87500rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;-webkit-box-sizing:border-box;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180620\/15294802384.png"},"imgstyle":"height:32.81250rpx"}};
                        return mappDate;
                    }
                    function router(){
                        return "page10003";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "我的";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [{"name":"newpersonal1"}];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                