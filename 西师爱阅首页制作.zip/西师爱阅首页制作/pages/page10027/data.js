
                    function appData(){
                        var mappDate = {"topNav0":"","album1":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:0px;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293985231.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293985231.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293985699.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293985699.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293985818.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293985818.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293985923.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293985923.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293986018.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293986018.png\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180619\/15293986199.png","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:346.87500rpx;border-radius:23.43750rpx;","img_style":"height:234.37500rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);","eventHandler":"bindExpand","eventParams":"{\"path\":\"http:\\\/\\\/make.suchengapp.com\\\/upload\\\/images\\\/20180619\\\/15293986199.png\"}"}]},"freeVessel2":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:145.31250rpx;","content":[{"type":"picture","style":"width:140.62500rpx;height:140.62500rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:595.31250rpx;top:0px;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292402831.jpg"},"eventHandler":"bindMap","eventParams":"{\"mapnid\":\"OnShmV\",\"mapname\":\"\\u4e09\\u4e9a\\u5eb7\\u5e74\\u9152\\u5e97\"}","imgstyle":"height:140.62500rpx"},{"type":"text","style":"color:#353535;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:445.31250rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:58.59375rpx;top:75.00000rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4e09\u4e9a\u5e02\u5929\u6daf\u533a\u4e09\u4e9a\u6e7e\u8def189\u53f7"},{"type":"text","style":"color:#000000;font-size:35.15625rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:257.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;left:18.75000rpx;top:14.06250rpx;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u4e09\u4e9a\u5eb7\u5e74\u9152\u5e97 "},{"type":"picture","style":"width:46.87500rpx;height:46.87500rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;border-radius:0px;opacity:1;left:28.12500rpx;top:77.34375rpx;max-width:100%;","content":{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180617\/15292408424.png"},"imgstyle":"height:46.87500rpx"}]},"text3":{"type":"text","style":"color:#ff9900;font-size:32.81250rpx;text-align:center;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:9.37500rpx;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:rgb(255, 153, 0);box-shadow:rgb(255, 153, 0) 0px 1px 2px;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:23.43750rpx;","content":"\u8ba2\u623f\u70ed\u7ebf\uff1a0898-88685888","eventHandler":"tapPhoneCallHandler","eventParams":"{\"phonenum\":\"089888685888\"}"},"text4":{"type":"text","style":"color:#38761d;font-size:30.46875rpx;text-align:center;max-width:100%;line-height:93.75000rpx;background:rgba(0,0,0,0);width:750.00000rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:0px;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"\u6682\u4e0d\u652f\u6301\u5728\u7ebf\u8ba2\u623f\uff0c\u8bf7\u76f4\u63a5\u7535\u8bdd\u9884\u7ea6\uff01"},"title5":{"type":"title","style":"line-height:70.31250rpx;margin-top:14.06250rpx;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(255, 255, 255);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u9152\u5e97\u4ecb\u7ecd","markColor":"rgb(48, 170, 245)","mode":0},"text6":{"type":"text","style":"color:#626262;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:679.68750rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"       \u4e09\u4e9a\u5eb7\u5e74\u9152\u5e97\u4f4d\u4e8e\u4e09\u4e9a\u6e7e\u8def\u4e2d\u6bb5\uff0c\u8ddd\u79bb\u4e09\u4e9a\u5e02\u533a\u7ea615\u5206\u949f\u8f66\u7a0b\uff0c\u6b65\u884c2\u5206\u949f\u53ef\u8fbe\u516c\u4ea4\u8f66\u7ad9\uff0c\u5404\u9879\u4ea4\u901a\u4fbf\u5229\u3002\n\u3000\u3000\u5c4b\u9876\u65e0\u8fb9\u9645\u6cf3\u6c60\u3001\u60ac\u6311\u900f\u660e\u6cf3\u6c60\u7b495\u4e2a\u6e38\u6cf3\u6c60\uff0c\u8fd8\u6709\u6b63\u5b97\u7684\u6cf0\u5f0fSpa,\u4f53\u9a8c\u539f\u6c41\u539f\u5473\u7684\u4f20\u7edf\u6cf0\u5f0f\u6309\u6469\uff0c\u8ba9\u60a8\u7684\u8eab\u5fc3\u60ec\u610f\u653e\u677e\uff0c\u7545\u4eab\u6109\u60a6\u5047\u671f\u3002\n       \u9152\u5e97\u62e5\u67091200\u5e73\u7c73\u7684\u4ff1\u4e50\u90e8,\u513f\u7ae5\u6cf3\u6c60\uff0c\u70ed\u5e26\u56ed\u6797\uff0c\u4eb2\u6d77\u6c99\u6ee9\uff0c\u5e26\u4e0a\u5b69\u5b50\uff0c\u5c3d\u4eab\u5bb6\u5ead\u6b22\u4e50\u65f6\u5149"},"button7":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:23.43750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u8fd4 \u56de","eventHandler":"tapBack"},"freeVessel8":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:35.15625rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10027";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "三亚康年酒店 ";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                