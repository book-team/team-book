
                    function appData(){
                        var mappDate = {"topNav0":"","title1":{"type":"title","style":"line-height:93.75000rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(243, 243, 243);color:#222222;text-align:left;font-size:32.81250rpx;","content":"\u5357\u5c71\u5bfa \u00b7 \u666f\u70b9\u7b80\u4ecb","markColor":"rgb(48, 170, 245)","mode":"1"},"text2":{"type":"text","style":"color:#444444;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"      \u6d77\u5357\u7701\u4e09\u4e9a\u5e02\u5357\u5c71\u5bfa\uff0c\u4f4d\u4e8e\u6d77\u5357\u7701\u4e09\u4e9a\u5e02\u4ee5\u897f40\u516c\u91cc\u5357\u5c71\u6587\u5316\u65c5\u6e38\u533a\u5185\u7684\u201c\u4f5b\u6559\u6587\u5316\u516c\u56ed\u201d\u4e2d\u3002\u636e\u53f2\u5fd7\u6240\u8f7d\uff0c\u4e09\u4e9a\u5357\u5c71\u5373\u83e9\u8428\u957f\u5c45\u4e4b\u201c\u8865\u601b\u6d1b\u8fe6\u201d\uff0c\u6709\u201c\u5927\u5149\u660e\u5c71\u201d\u4e4b\u79f0\uff0c\u4e09\u4e9a\u5357\u5c71\u5bfa\u5360\u5730400\u4ea9\uff0c\u4eff\u5510\u98ce\u683c\uff0c\u5efa\u6709\u4ec1\u738b\u6bbf\u3001\u5927\u96c4\u5b9d\u6bbf\u3001\u4e1c\u897f\u914d\u6bbf\u3001\u949f\u9f13\u697c\u3001\u8f6c\u8f6e\u85cf\u3001\u6cd5\u5802\u3001\u89c2\u97f3\u9662\u3001\u60b2\u7530\u9662\u7b49\uff0c\u4f9d\u5c71\u5c31\u52bf\uff0c\u9519\u843d\u6709\u81f4\uff0c\u5e84\u4e25\u8083\u7a46\uff0c\u6e05\u51c0\u5e7d\u96c5\u3002\u5165\u5176\u5883\u82e5\u5165\u771f\u89c2\u97f3\u83e9\u8428\u8bf4\u6cd5\u4e4b\u9053\u573a\u3002"},"map3":{"type":"map","style":"width:750.00000rpx;height:351.56250rpx;margin-top:23.43750rpx;margin-left:0px;color:#38761d;font-size:30.46875rpx;text-align:center;font-weight:normal;font-style:normal;text-decoration:none;","showmap":true,"content":"\u6d77\u5357\u7701\u4e09\u4e9a\u5e02\u5d16\u5dde\u533a\u5357\u5c71\u6587\u5316\u65c5\u6e38\u533a","lat":18.306021,"lng":109.213188,"markers":[{"latitude":18.306021,"longitude":109.213188}],"compid":"map3"},"button4":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:4.68750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u5730\u56fe\u5bfc\u822a","eventHandler":"bindMap","eventParams":"{\"mapnid\":\"usggxQ\",\"mapname\":\"\\u5357\\u5c71\\u5bfa\"}"},"album5":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:23.43750rpx;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/21529134867.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/31529134905.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/21529134932.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/101529134960.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20180616\/31529134988.jpg","title":"","li_class":"album-pic","li_style":"margin-left:18.75000rpx;margin-top:9.37500rpx;width:712.50000rpx;border-radius:23.43750rpx;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"}]},"title6":{"type":"title","style":"line-height:70.31250rpx;margin-top:0px;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;font-weight:normal;font-style:normal;text-decoration:none;background:rgb(243, 243, 243);color:#222222;text-align:left;font-size:35.15625rpx;","content":"\u7279\u522b\u63d0\u9192","markColor":"rgb(48, 170, 245)","mode":1},"text7":{"type":"text","style":"color:#444444;font-size:30.46875rpx;text-align:left;max-width:100%;line-height:58.59375rpx;background:rgba(0,0,0,0);width:703.12500rpx;font-weight:normal;font-style:normal;text-decoration:none;margin-top:0px;margin-left:auto;margin-right:auto;border-style:none;border-width:0px;border-color:#000000;box-shadow:none;white-space:pre-wrap;word-break:break-all;-webkit-box-sizing:border-box;border-radius:0px;","content":"1. \u5357\u5c71\u62d2\u70e7\u9ad8\u9999\u548c\u5e26\u5927\u9999\u5165\u56ed\uff0c\u56ed\u533a\u5185\u5404\u4e2a\u4f5b\u6559\u9053\u573a\u5747\u514d\u8d39\u8d60\u9999\u793c\u4f5b\uff0c\u4e0d\u8981\u5728\u5916\u9762\u4e70\u9999\u4ee5\u514d\u6d6a\u8d39\u94b1\u8d22\u3002\n2. \u5357\u5c71\u6587\u5316\u65c5\u6e38\u533a\u5185\u7684\u7f18\u8d77\u697c\u7d20\u658b\u9910\u5385\uff0c\u63d0\u4f9b\u201c\u5bfa\u9662\u7d20\u658b\u201d\u81ea\u52a9\u83dc\u80b4\uff0c\u6781\u5177\u4f5b\u5bb6\u7279\u8272\uff0c\u53ef\u4f5c\u4e3a\u5348\u9910\u5730\u70b9\u3002\n3. \u5357\u5c71\u6587\u5316\u65c5\u6e38\u533a\u91cc\u5efa\u6709\u5357\u5c71\u8fce\u5bbe\u9986\uff0c\u53e3\u7891\u8fd8\u4e0d\u9519\uff0c\u6709\u9700\u8981\u7684\u4e5f\u53ef\u4ee5\u9009\u62e9\u5165\u4f4f\u3002"},"button8":{"type":"button","style":"color:#ffffff;font-size:32.81250rpx;text-align:center;width:281.25000rpx;max-width:100%;line-height:65.62500rpx;height:65.62500rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:23.43750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u8fd4 \u56de","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10001\",\"inner_page_link\":\"\\\/pages\\\/page10001\\\/page10001\"}"},"freeVessel9":{"type":"freeVessel","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:rgba(0,0,0,0);width:750.00000rpx;height:35.15625rpx;","content":[]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10011";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "南山寺";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                