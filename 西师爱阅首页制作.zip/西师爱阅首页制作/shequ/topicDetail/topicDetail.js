var WxParse = require('../../components/wxParse/wxParse.js');
var app = getApp();
var id;
Page({
    data: {
        srcoll: 'auto',
        isLikeShow: false,
        isCommentShow: true,
        topicTypeNavTab: '',
        commentList: '',
        hideComment: '',
    },
    onLoad: function (e) {
        var that = this;
        id = e.id;
        var sWidth;
        wx.getSystemInfo({
            success: function (res) {
                sWidth = res.windowWidth - 20;
            }
        })
        app.sendRequest({
            url: '/webapp/Api/getTopicDetail',
            data: {
                id: id
            },
            method: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var newdata = {};
                    newdata['data'] = res.data;
                    var urls = [];
                    for (var i = 0; i < res.data.imageList.length; i++) {
                        urls.push(res.data.imageList[i].pic_path);
                    }
                    newdata['imgurls'] = urls;
                    newdata['topicData'] = res.data.topicData;
                    newdata['commentList'] = res.data.commentList;
                    newdata['pageshow'] = true;
                    newdata['nothing'] = false;
                    that.setData(newdata);
                    wx.setNavigationBarTitle({
                        title: res.data.title
                    })
                }
                if (res.code == 100) {
                    that.setData({
                        pageshow: true,
                        nothing: true
                    })
                    wx.setNavigationBarTitle({
                        title: '话题过期不存在'
                    })
                }
                if (res.code == 1000 || res.code == 2000) {
                    that.setData({
                        pageshow: true,
                        vqdlevel: res.code
                    })
                    wx.setNavigationBarTitle({
                        title: '待升级提示'
                    });
                }
            }
        });
    },
    onShow: function () {
        app.setPageUserInfo();
    },
    nav: function (e) {
        var that = this;
        var newdata = { topicTypeNavTab: app.getset(e).tab };
        newdata['isCommentShow'] = true;
        newdata['isLikeShow'] = false;
        if (app.getset(e).tab == 1) {
            newdata['isCommentShow'] = false;
            newdata['isLikeShow'] = true;
        }
        that.setData(newdata);
    },
    clickLike: function (e) {
        var that = this;
        app.sendRequest({
            url: '/webapp/Api/addTopiclike',
            data: {
                topicId: id,
                openid: app.getSessionKey(),
            },
            method: 'post',
            success: function (data) {
                if (data.code == 1) {
                    var newdata = {};
                    newdata['data.like'] = that.data.data.like + 1;
                    that.setData(newdata);
                }
                if (data.code == 3) {
                    app.toast({ title: '你已经点赞过了！' });
                }
            }
        });
    },
    updateComment: function (id) {
        var that = this;
        app.sendRequest({
            url: '/webapp/Api/getTopicDetail',
            data: {
                id: id
            },
            method: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var newdata = {};
                    newdata['data'] = res.data;
                    newdata['topicData'] = res.data.topicData;
                    newdata['commentList'] = res.data.commentList;
                    newdata['pageshow'] = true;
                    newdata['nothing'] = false;
                    that.setData(newdata);
                }
            }
        });
    }, backhome: function () {
        app.backhome();
    },
    clickCommentLike: function (e) {
        var that = this,
            id = app.getset(e).id,
            key = app.getset(e).keydata;
        app.sendRequest({
            url: '/webapp/Api/addTopicCommentLike',
            data: {
                commentId: app.getset(e).id,
                openid: app.getSessionKey(),
            },
            method: 'post',
            success: function (data) {
                if (data.code == 1) {
                    var newdata = {};
                    newdata['commentList[' + key + '].like'] = that.data.commentList[key].like + 1;
                    that.setData(newdata);
                }
                if (data.code == 3) {
                    app.toast({ title: '你已经点赞过了！' });
                }
            }
        });
    }, showAll: function (e) {
        var that = this,
            pid = app.getset(e).pid,
            key = app.getset(e).key;
        app.sendRequest({
            url: '/webapp/Api/getTopicCommentAll',
            data: {
                pid: pid
            },
            method: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var newdata = {};
                    newdata['commentList[' + key + '].subInfo'] = res.list;
                    newdata['hideComment'] = pid;
                    that.setData(newdata);
                }
            }
        });
    },
    previewImg: function (e) {
        app.previewImage(e);
    },
    openAuthor: function () {
        app.openAuthor();
    },
    refuseAuthor: function () {
        app.refuseAuthor();
    },
    clickAuthor: function () {
        app.clickAuthor();
    },
    getuserinfo: function (e) {
        app.getuserinfo(e);
    },
    addTopicComment: function (e) {
        var id = app.getset(e).id;
        var pid = app.getset(e).pid;
        var path = "/shequ/addTopicComment/addTopicComment?id=" + id + '&pid=' + pid;
        app.turnToPage(path)
    },
    closenewgift: function () {
        app.closenewgift();
    },
})