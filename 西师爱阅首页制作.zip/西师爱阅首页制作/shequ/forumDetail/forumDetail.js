var WxParse = require('../../components/wxParse/wxParse.js');
var app = getApp();
var id;
Page({
    test: '',
    data: {
        srcoll: 'auto',
        topicCategoryTab: 0,
        topicIsMore: false,
        topicSearch: '',
        id: '',
        hideComment: '',
        categoryAlias: ''
    },
    onLoad: function (e) {
        var that = this;
        id = e.id;
        that.setData({
            id: id
        })
        var sWidth;
        wx.getSystemInfo({
            success: function (res) {
                sWidth = res.windowWidth - 20;
            }
        })
        app.sendRequest({
            url: '/webapp/Api/getForumDetail',
            data: {
                id: id
            },
            method: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var newdata = {};
                    newdata['data'] = res.data;
                    newdata['carousel'] = res.data.carousel;
                    newdata['topicData'] = res.data.topic;
                    newdata['topicIsMore'] = res.data.topicIsMore;
                    newdata['pageshow'] = true;
                    newdata['nothing'] = false;
                    that.setData(newdata);
                    wx.setNavigationBarTitle({
                        title: res.data.name
                    })
                }
                if (res.code == 100) {
                    that.setData({
                        pageshow: true,
                        nothing: true
                    })
                    wx.setNavigationBarTitle({
                        title: '话题过期不存在'
                    })
                }
                if (res.code == 1000 || res.code == 1000) {
                    that.setData({
                        pageshow: true,
                        vqdlevel: res.code
                    })
                    wx.setNavigationBarTitle({
                        title: '待升级提示'
                    });
                }
            }
        });
    },
    nav: function (e) {
        var that = this;
        this.setData({
            topicCategoryTab: app.getset(e).id,
            categoryAlias: app.getset(e).alias
        });
        app.sendRequest({
            url: '/webapp/Api/getTopicAll',
            data: {
                forumId: id,
                categoryId: app.getset(e).id
            },
            method: 'post',
            success: function (data) {
                that.setData({
                    topicData: data.data.list,
                    topicIsMore: data.data.topicIsMore
                });
            }
        });
    },
    clickLike: function (e) {
        var that = this,
            key = app.getset(e).keydata;
        app.sendRequest({
            url: '/webapp/Api/addTopiclike',
            data: {
                topicId: app.getset(e).topicid,
                openid: app.getSessionKey(),
            },
            method: 'post',
            success: function (data) {
                if (data.code == 1) {
                    var newdata = {};
                    newdata['topicData[' + key + '].like'] = that.data.topicData[key].like + 1;
                    that.setData(newdata);
                }
                if (data.code == 3) {
                    app.toast({ title: '你已经点赞过了！' });
                }
            }
        });
    },
    topicMore: function (e) {
        var that = this;
        app.sendRequest({
            url: '/webapp/Api/getTopicAll',
            data: {
                forumId: id,
                categoryId: that.data.topicCategoryTab,
                limit: 'all'
            },
            method: 'post',
            success: function (data) {
                if (data.code == 200) {
                    that.setData({
                        topicIsMore: false,
                        topicData: data.data.list
                    });
                }
            }
        });
    },
    bindInput: function (e) {
        this.setData({
            topicSearch: e.detail.value,
        });
    },
    topicSearch: function (e) {
        var that = this;
        app.sendRequest({
            url: '/webapp/Api/getTopicAll',
            data: {
                forumId: that.data.id,
                topicSearch: that.data.topicSearch,
                limit: 'all'
            },
            method: 'post',
            success: function (data) {
                if (data.code == 200) {
                    that.setData({
                        topicData: data.data.list
                    });
                }
            }
        });
    },
    backhome: function () {
        app.backhome();
    },
    updateData: function (id) {
        var that = this;
        app.sendRequest({
            url: '/webapp/Api/getForumDetail',
            data: {
                id: id
            },
            method: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var newdata = {};
                    newdata['data'] = res.data;
                    newdata['carousel'] = res.data.carousel;
                    newdata['topicData'] = res.data.topic;
                    newdata['topicIsMore'] = res.data.topicIsMore;
                    that.setData(newdata);
                }
            }
        });
    },
    picUrl: function (e) {
        var id = app.getset(e).id;
        wx.navigateTo({
            url: '/shequ/topicDetail/topicDetail?id=' + id
        });
    },
    showAll: function (e) {
        var that = this,
            id = app.getset(e).id,
            key = app.getset(e).key;
        app.sendRequest({
            url: '/webapp/Api/getTopicCommentAll',
            data: {
                topicId: id
            },
            method: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var newdata = {};
                    newdata['topicData[' + key + '].commentList'] = res.list;
                    newdata['hideComment'] = key;
                    that.setData(newdata);
                }
            }
        });
    },
    onShow: function () {
        app.setPageUserInfo();
        var that = this;
        app.sendRequest({
            url: '/webapp/Api/getForumDetail',
            data: {
                id: id
            },
            method: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var newdata = {};
                    newdata['data'] = res.data;
                    newdata['carousel'] = res.data.carousel;
                    newdata['topicData'] = res.data.topic;
                    newdata['topicIsMore'] = res.data.topicIsMore;
                    newdata['pageshow'] = true;
                    newdata['nothing'] = false;
                    that.setData(newdata);
                }
            }
        });
    },
    openAuthor: function () {
        app.openAuthor();
    },
    refuseAuthor: function () {
        app.refuseAuthor();
    },
    clickAuthor: function () {
        app.clickAuthor();
    },
    getuserinfo: function (e) {
        app.getuserinfo(e);
    },
    addTopic: function (e) {
        var id = app.getset(e).id;
        var path = "/shequ/addTopic/addTopic?id=" + id;
        app.turnToPage(path)
    },
    closenewgift: function () {
        app.closenewgift();
    },
})