var app = getApp();
Page({
    data: {
        searchtext: '',
        inputText: '',
        inputstype: ''
    },
    prenum: 0,
    pagenum: 1,
    havenums: 1,
    onLoad: function (e) {
        var that = this;
        var inputstype = e.inputstype || 'border-radius:11.71875rpx;';
        this.setData({
            inputstype: inputstype
        })
        wx.getStorage({
            key: 'artData',
            success: function (res) {
                that.setData({
                    TopicList: res.data
                });
            }
        });
        wx.setNavigationBarTitle({
            title: '话题搜索'
        })
    },
    tagSearch: function (e) {
        let text = e.target.dataset.text;
        this.setData({
            searchtext: text
        });
        this.setData({
            [`TopicList.content`]: [],
            searchNothing: true
        });
        this.resetNum();
        this.search();
    },
    enterSearhText: function (e) {
        var value = e.detail.value;
        this.setData({
            inputText: value
        });
    },
    clickSearch: function () {
        var text = this.data.inputText;
        this.setData({
            searchtext: text
        });
        if (text != '') {
            this.setData({
                [`TopicList.content`]: [],
                searchNothing: true
            });
            this.resetNum();
            this.search();
        }
    },
    searchMore: function () {
        var prenum = this.prenum;
        var pagenum = this.pagenum;
        var havenums = this.havenums;
        if (prenum != pagenum && havenums != 0) {
            this.prenum = pagenum;
            this.search();
        }
    },
    search: function () {
        var that = this;
        let listid = this.data.TopicList.listid;
        let text = this.data.searchtext;
        var pagenum = this.pagenum;
        app.sendRequest({
            url: '/webapp/Api/getTopicAll',
            data: {
                title: text,
                nid: listid,
                pageNum: pagenum
            },
            method: 'post',
            success: function (res) {
                var newdata = {};
                if (res.code == 200) {
                    that.havenums = res.havenums;
                    that.pagenum = that.pagenum + 1;
                    var oldlist = that.data.TopicList.content;
                    newdata['TopicList.content'] = oldlist.concat(res.data.list);
                    that.setData(newdata);
                }
            }
        });
    },
    resetNum: function () {
        this.prenum = 0;
        this.pagenum = 1;
        this.havenums = 1;
    }
})