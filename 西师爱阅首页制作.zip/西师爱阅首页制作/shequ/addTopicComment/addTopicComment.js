var WxParse = require('../../components/wxParse/wxParse.js');
var app = getApp();
var id;
var pid;
Page({
    data: {
        index: '',
        id: '',
        pid: '',
        comment: '',
    },
    onLoad: function (e) {
        var that = this;
        id = e.id;
        pid = e.pid;
        var sWidth;
        app.sendRequest({
            url: '/webapp/Api/getTopicDetail',
            data: {
                id: id
            },
            method: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var newdata = {};
                    newdata['data'] = res.data;
                    that.setData(newdata);
                }
            }
        });
        wx.setNavigationBarTitle({
            title: '发布话题'
        });
    },
    bindInput: function (e) {
        this.setData({
            comment: e.detail.value,
        });
    },
    sendcomment: function (e) {
        var that = this,
            text = that.data.comment;
        if (text == '') {
            app.toast({ title: '请输入评论！' });
            return;
        }
        app.sendRequest({
            url: '/webapp/Api/addTopicComment',
            data: {
                topicId: id,
                pid: pid,
                content: text,
                openid: app.getSessionKey(),
            },
            method: 'post',
            success: function (data) {
                if (data.code == 1) {
                    var pages = getCurrentPages();
                    var lastPage = pages[pages.length - 2];
                    lastPage.updateComment(id);
                    wx.navigateBack({
                        delta: 1
                    })
                } else {
                    app.toast({ title: data.msg })
                    return;
                }
            }
        });
    },
    back: function (e) {
        wx.navigateBack({
            delta: 1
        })
    }
})