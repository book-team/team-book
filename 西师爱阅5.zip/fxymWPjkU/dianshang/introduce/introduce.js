var app = getApp();
Page({
    data: {
        introduce_bg: app.globalData.siteBaseUrl + '/static/newuser/images/introduce_bg.jpg',
    },
    onLoad: function (e) {
    },
})