var WxParse = require('../../components/wxParse/wxParse.js');
var app = getApp();
var id;
Page({
    data: {
        tab: 1,
        publish: '',
        reply: '',
        id: '',
        isReply: false,
        isPublish: true,
    },
    onLoad: function (e) {
        var that = this;
        id = e.id;
        that.setData({
            id: id
        })
        var sWidth;
        wx.getSystemInfo({
            success: function (res) {
                sWidth = res.windowWidth - 20;
            }
        })
        app.sendRequest({
            url: '/webapp/Api/getUserInfoDetail',
            data: {
                id: id,
                openid: app.getSessionKey(),
            },
            method: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var newdata = {};
                    newdata['publish'] = res.topic.list;
                    newdata['reply'] = res.comment;
                    newdata['pageshow'] = true;
                    that.setData(newdata);
                    wx.setNavigationBarTitle({
                        title: '个人中心'
                    })
                }
                if (res.code == 100) {
                    that.setData({
                        pageshow: true,
                        nothing: true
                    })
                    wx.setNavigationBarTitle({
                        title: '个人中心'
                    })
                }
            }
        });
    },
    nav: function (e) {
        var that = this,
            newdata = {},
            tab = app.getset(e).tab;
        newdata['isReply'] = false;
        newdata['isPublish'] = true;
        if (tab == 2) {
            newdata['isReply'] = true;
            newdata['isPublish'] = false;
        }
        newdata['tab'] = tab;
        this.setData(newdata);
    },
    back: function (e) {
        wx.navigateBack({
            delta: 1
        })
    }, backhome: function () {
        app.backhome();
    }
})