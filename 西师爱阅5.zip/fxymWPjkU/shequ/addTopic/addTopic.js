var WxParse = require('../../components/wxParse/wxParse.js');
var app = getApp();
var id;
Page({
    data: {
        index: '',
        id: '',
        formInfo: [],
        image: [],
        uploadicon_pic: app.globalData.siteBaseUrl + '/static/user/images/topic_icon9.jpg'
    },
    onLoad: function (e) {
        var that = this;
        id = e.id;
        that.setData({
            id: id
        })
        var sWidth;
        wx.getSystemInfo({
            success: function (res) {
                sWidth = res.windowWidth - 20;
            }
        })
        app.sendRequest({
            url: '/webapp/Api/getCategoryAll',
            data: {
                forumId: id
            },
            method: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var newdata = {},
                        val = [];
                    for (var i in res.list) {
                        if (i == 0) {
                            newdata['index'] = i;
                        }
                        val[i] = { id: res.list[i].id, name: res.list[i].name };
                    }
                    newdata['category'] = val;
                    newdata['data'] = res.data;
                    newdata['pageshow'] = true;
                    that.setData(newdata);
                    wx.setNavigationBarTitle({
                        title: '评论该话题'
                    })
                }
                if (res.code == 100) {
                    that.setData({
                        pageshow: true,
                        nothing: true
                    })
                    wx.setNavigationBarTitle({
                        title: '评论该话题'
                    })
                }
            }
        });
    },
    uploadFormImg: function (e) {
        var that = this;
        let dataset = app.getset(e);
        let pageInstance = app.getNowPage();
        if (that.data.image.length >= 9) {
            app.toast({ title: '图片不能超过9张' });
            return;
        }
        app.chooseImage(function (res) {
            let img_src = res;
            let newdata = {};
            let imageUrl = that.data.image;
            imageUrl.push(img_src);
            newdata['image'] = imageUrl;
            pageInstance.setData(newdata);
        });
    },
    listenerPickerSelected: function (e) {
        this.setData({
            index: e.detail.value
        })
    },
    formBindsubmit: function (e) {
        var that = this,
            title = e.detail.value.title,
            content = e.detail.value.content,
            forum_category_id = that.data.category[that.data.index].id,
            picPath = that.data.image;
        app.sendRequest({
            url: '/webapp/Api/addTopic',
            data: {
                forum_id: id,
                title: title,
                forum_category_id: forum_category_id,
                openid: app.getSessionKey(),
                content: content,
                picPath: picPath,
            },
            method: 'post',
            success: function (data) {
                if (data.code == '200') {
                    app.toast({ title: data.msg })
                    setTimeout(function () {
                        var pages = getCurrentPages();
                        var lastPage = pages[pages.length - 2];
                        lastPage.updateData(id);
                        wx.navigateBack({
                            delta: 1
                        });
                    }, 1000);
                } else {
                    app.toast({ title: data.msg })
                    return;
                }
            }
        });
    },
    removeCarousel: function (e) {
        let newdata = {};
        var key = app.getset(e).key;
        newdata['image'] = this.data.image.splice(0, key);
        this.setData(newdata);
    }
})