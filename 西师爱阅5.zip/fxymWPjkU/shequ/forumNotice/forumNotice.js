var WxParse = require('../../components/wxParse/wxParse.js');
var app = getApp();
var id;
Page({
    data: {
        tab: 1,
        commentData: '',
        likeData: '',
        id: '',
        isComment: false,
        isLike: true,
    },
    onLoad: function (e) {
        var that = this;
        id = e.id;
        that.setData({
            id: id
        })
        var sWidth;
        wx.getSystemInfo({
            success: function (res) {
                sWidth = res.windowWidth - 20;
            }
        })
        app.sendRequest({
            url: '/webapp/Api/getNoticeDetail',
            data: {
                id: id,
                openid: app.getSessionKey()
            },
            method: 'post',
            success: function (res) {
                if (res.code == 200) {
                    var newdata = {};
                    newdata['likeData'] = res.like;
                    newdata['commentData'] = res.comment;
                    newdata['pageshow'] = true;
                    that.setData(newdata);
                    wx.setNavigationBarTitle({
                        title: '通知中心'
                    })
                }
                if (res.code == 100) {
                    that.setData({
                        pageshow: true,
                        nothing: true
                    })
                    wx.setNavigationBarTitle({
                        title: '通知中心'
                    })
                }
            }
        });
    },
    nav: function (e) {
        var that = this,
            newdata = {},
            tab = app.getset(e).tab;
        newdata['isComment'] = false;
        newdata['isLike'] = true;
        if (tab == 2) {
            newdata['isComment'] = true;
            newdata['isLike'] = false;
        }
        newdata['tab'] = tab;
        this.setData(newdata);
    },
    back: function (e) {
        wx.navigateBack({
            delta: 1
        })
    }, backhome: function () {
        app.backhome();
    }
})