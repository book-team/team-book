
                    function appData(){
                        var mappDate = {"topNav0":"","dynamicform1":{"type":"dynamicform","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:#ffffff;","content":[{"type":"singletext","style":"margin-top:35.15625rpx;margin-left:auto;margin-right:auto;opacity:1;border-radius:0px;width:679.68750rpx;height:96.09375rpx;","compId":"data.content[0]","formCompid":"dynamicform1","segment":"","isneed":"2","content":"\u8bf7\u586b\u5199\u60a8\u7684\u6635\u79f0","namestyle":"font-size:42.18750rpx;color:#000000;max-width:31%;height:100%;line-height:96.09375rpx;display:inline-block;float:left;","contentstyle":"font-size:35.15625rpx;color:#000000;border-radius:35.15625rpx;width:67%;height:100%;float:left;margin-left:2%;","textname":"\u6635\u79f0","choosenum":0}],"form":"","compId":"dynamicform1","formCompid":"dynamicform1"},"dynamicform2":{"type":"dynamicform","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:#ffffff;","content":[{"type":"singletext","style":"margin-top:35.15625rpx;margin-left:auto;margin-right:auto;opacity:1;border-radius:0px;width:679.68750rpx;height:96.09375rpx;","compId":"data.content[0]","formCompid":"dynamicform2","segment":"","isneed":"2","content":"\u5973\/\u7537","namestyle":"font-size:42.18750rpx;color:#000000;max-width:31%;height:100%;line-height:96.09375rpx;display:inline-block;float:left;","contentstyle":"font-size:35.15625rpx;color:#000000;border-radius:35.15625rpx;width:67%;height:100%;float:left;margin-left:2%;","textname":"\u6027\u522b","choosenum":0}],"form":"","compId":"dynamicform2","formCompid":"dynamicform2"},"dynamicform3":{"type":"dynamicform","style":"margin-top:0px;margin-left:0px;margin-right:auto;box-shadow:none;opacity:1;background:#ffffff;","content":[{"type":"singletext","style":"margin-top:35.15625rpx;margin-left:auto;margin-right:auto;opacity:1;border-radius:0px;width:679.68750rpx;height:96.09375rpx;","compId":"data.content[0]","formCompid":"dynamicform3","segment":"","isneed":"2","content":"\u8bf7\u8f93\u5165\u624b\u673a\u53f7","namestyle":"font-size:42.18750rpx;color:#000000;max-width:31%;height:100%;line-height:96.09375rpx;display:inline-block;float:left;","contentstyle":"font-size:35.15625rpx;color:#000000;border-radius:35.15625rpx;width:67%;height:100%;float:left;margin-left:2%;","textname":"\u8054\u7cfb\u7535\u8bdd","choosenum":0}],"form":"","compId":"dynamicform3","formCompid":"dynamicform3"},"button4":{"type":"button","style":"color:#ffffff;font-size:46.87500rpx;text-align:center;width:703.12500rpx;max-width:100%;line-height:70.31250rpx;height:70.31250rpx;background:rgb(48, 170, 245);margin-left:auto;margin-right:auto;margin-top:46.87500rpx;opacity:1;border-radius:0px;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u5b66\u6821\u8ba4\u8bc1"},"button5":{"type":"button","style":"color:#ffffff;font-size:46.87500rpx;text-align:center;width:703.12500rpx;max-width:100%;line-height:70.31250rpx;height:70.31250rpx;background:rgb(9, 187, 7);margin-left:23.43750rpx;margin-right:auto;margin-top:46.87500rpx;opacity:1;border-radius:0px;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;","content":"\u63d0\u4ea4"}};
                        return mappDate;
                    }
                    function router(){
                        return "page10050";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "个人信息";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                