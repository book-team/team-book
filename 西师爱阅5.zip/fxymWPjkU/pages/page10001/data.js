
                    function appData(){
                        var mappDate = {"topNav0":"","teletext1":{"type":"teletext","style":"width:100%;margin-top:0px;background:#ffffff;opacity:1;display:block;","content":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/71592255490.jpg","title":"\u8349\u539f\u4e0a\u7684\u5c0f\u6728\u5c4b","secTitle":"\u5df2\u5b8c\u7ed3 \u517122\u7ae0","imgStyle":"width:117.18750rpx;height:750.00000rpx;margin-left:23.43750rpx;","listStyle":"background:#e8e8e8;height:140.62500rpx;margin-bottom:16.40625rpx;","titleWidth":"width:562.50000rpx;vertical-align:middle;","titlefont":"font-size:37.50000rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:#000000;","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:#626262;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10046\",\"inner_page_link\":\"\\\/pages\\\/page10046\\\/page10046\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/31592255636.jpg","title":"\u6c34\u6d52\u4f20","secTitle":"\u8bfb\u81f3\u7b2c8\u7ae0 \u517174\u7ae0","imgStyle":"width:117.18750rpx;height:750.00000rpx;margin-left:23.43750rpx;","listStyle":"background:#e8e8e8;height:140.62500rpx;margin-bottom:16.40625rpx;","titleWidth":"width:562.50000rpx;vertical-align:middle;","titlefont":"font-size:37.50000rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:#000000;","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:#626262;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10047\",\"inner_page_link\":\"\\\/pages\\\/page10047\\\/page10047\"}"}]},"teletext2":{"type":"teletext","style":"width:100%;margin-top:0px;background:#ffffff;opacity:1;display:block;","content":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/21592255830.jpg","title":"\u540e\u79c0","secTitle":"\u8bfb\u81f3\u7b2c9\u7ae0 \u517133\u7ae0","imgStyle":"width:117.18750rpx;height:750.00000rpx;margin-left:23.43750rpx;","listStyle":"background:#e8e8e8;height:164.06250rpx;margin-bottom:16.40625rpx;","titleWidth":"width:585.93750rpx;vertical-align:middle;","titlefont":"font-size:37.50000rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:#000000;","abstractfont":"font-size:28.12500rpx;font-style:normal;font-weight:normal;text-decoration:none;text-align:left;color:#626262;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10048\",\"inner_page_link\":\"\\\/pages\\\/page10048\\\/page10048\"}"}]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10001";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "书架";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                