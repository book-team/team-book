var app = getApp();
Page({
    prenum: 0,
    pagenum: 1,
    havenums: 1,
    data: {
    },
    onLoad: function (e) {
        this.setData({
            color: e.themecolor || '#e96262'
        })
        app.addIplog();
        app.checkLogin();
    },
    onShow: function () {
        app.setPageUserInfo();
        this.sureSearch();
    },
    dataInitial: function () {
    },
    onShareAppMessage: function () {
        var pageRouter = this.page_router;
        return {
            title: app.getAppTitle(),
            desc: app.getAppDescription(),
            path: '/jifen/integralMall/integralMall'
        }
    },
    backhome: function () {
        app.backhome();
    },
    goToIntegral: function () {
    },
    exchangeRecord: function () {
        var url = '/jifen/integralOrder/integralOrder';
        app.turnToPage(url);
    },
    enterText: function (e) {
        var val = e.detail.value;
        this.setData({
            searchText: val
        });
    },
    sureSearch: function () {
        this.pagenum = 1;
        this.havenums = 1;
        this.prenum = 0;
        this.setData({
            integral_good: [],
            nothing: false
        });
        this.loadData();
    },
    loadmore: function () {
        var prenum = this.prenum;
        var pagenum = this.pagenum;
        var havenums = this.havenums;
        if (prenum != pagenum && havenums != 0) {
            this.prenum = pagenum;
            this.loadData();
        }
    },
    loadData: function () {
        var that = this;
        var searchText = this.data.searchText;
        var pagenum = this.pagenum;
        app.sendRequest({
            url: '/webapp/integralGood_list',
            method: 'post',
            data: {
                goodsname: searchText,
                pageNum: pagenum,
                openid: app.getSessionKey()
            },
            success: function (res) {
                var newdata = {};
                newdata['nothing'] = true;
                if (res.code == 1) {
                    that.havenums = res.havenums;
                    that.pagenum = that.pagenum + 1;
                    var oldlist = that.data.integral_good || [];
                    newdata['integral_good'] = oldlist.concat(res.good);
                    newdata['integral'] = res.integral;
                } else if (res.code == 1000 || res.code == 2000) {
                    that.setData({
                        vqdlevel: res.code
                    });
                    wx.setNavigationBarTitle({
                        title: '待升级提示'
                    });
                }
                that.setData(newdata);
            }
        });
    },
    goToExchange: function (e) {
        var id = app.getset(e).id;
        var url = '/jifen/integralGoodDetail/integralGoodDetail?id=' + id;
        app.turnToPage(url);
    },
    clickAuthor: function () {
        app.clickAuthor();
    },
    getuserinfo: function (e) {
        app.getuserinfo(e);
    },
    closenewgift: function () {
        app.closenewgift();
    }
})