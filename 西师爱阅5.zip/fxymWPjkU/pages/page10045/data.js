
                    function appData(){
                        var mappDate = {"topNav0":"","button1":{"type":"button","style":"color:#888888;font-size:30.46875rpx;text-align:center;width:703.12500rpx;max-width:100%;line-height:70.31250rpx;height:70.31250rpx;background:rgb(241, 236, 236);margin-left:auto;margin-right:auto;margin-top:23.43750rpx;opacity:1;border-radius:11.71875rpx;box-shadow:none;border-style:none;border-width:0px;border-color:#000000;font-weight:normal;font-style:normal;text-decoration:none;display:block;","content":"\u67e5\u770b\u5168\u90e8","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10001\",\"inner_page_link\":\"\\\/pages\\\/page10001\\\/page10001\"}"},"carousel2":{"type":"carousel","style":"height:351.56250rpx;margin-left:auto;margin-right:auto;margin-top:0px;opacity:1;position:relative;overflow:hidden;","indicatorDots":true,"autoplay":true,"interval":2,"content":[]},"album3":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:0px;display:block;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/11592235749.png","title":"\u501f\u9605\u699c\u5355","li_class":"album-pic","li_style":"margin-left:21.09375rpx;margin-top:28.12500rpx;width:161.13281rpx;border-radius:4.68750rpx;","img_style":"height:114.84375rpx","text_style":"font-size:30.46875rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:rgb(53, 53, 53);position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10006\",\"inner_page_link\":\"\\\/pages\\\/page10006\\\/page10006\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/101592235669.png","title":"\u7b14\u8bb0\u79c0","li_class":"album-pic","li_style":"margin-left:21.09375rpx;margin-top:28.12500rpx;width:161.13281rpx;border-radius:4.68750rpx;","img_style":"height:114.84375rpx","text_style":"font-size:30.46875rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:rgb(53, 53, 53);position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10007\",\"inner_page_link\":\"\\\/pages\\\/page10007\\\/page10007\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/81592235834.png","title":"\u5206\u7c7b","li_class":"album-pic","li_style":"margin-left:21.09375rpx;margin-top:28.12500rpx;width:161.13281rpx;border-radius:4.68750rpx;","img_style":"height:114.84375rpx","text_style":"font-size:30.46875rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:rgb(53, 53, 53);position:static;background:none;","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10008\",\"inner_page_link\":\"\\\/pages\\\/page10008\\\/page10008\"}"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/51592235878.png","title":"\u5173\u4e8e\u6211\u4eec","li_class":"album-pic","li_style":"margin-left:21.09375rpx;margin-top:28.12500rpx;width:161.13281rpx;border-radius:4.68750rpx;","img_style":"height:114.84375rpx","text_style":"font-size:30.46875rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:rgb(53, 53, 53);position:static;background:none;"}]},"classify4":{"type":"classify","style":"height:82.03125rpx;margin-left:auto;margin-right:auto;margin-top:0px;opacity:1;background:rgb(0, 255, 0);font-size:32.81250rpx;font-style:normal;font-weight:normal;text-decoration:none;line-height:82.03125rpx;text-align:left;","content":[{"text":"\u6700\u65b0\u56fe\u4e66","eventHandler":"tapBack"},{"text":"\u70ed\u95e8\u56fe\u4e66","eventHandler":"tapInnerLinkHandler","eventParams":"{\"is_redirect\":0,\"actionPages\":\"page10044\",\"inner_page_link\":\"\\\/pages\\\/page10044\\\/page10044\"}"},{"text":"\u5fc5\u8bfb\u4e66\u76ee","eventHandler":"tapBack"}],"selected":0,"mode":0,"selectedColor":"rgb(13, 163, 249)","unselectColor":"#000000","mleft":"margin-left:65.62500rpx;","radius":5,"compid":"classify4"},"bottomNav5":"","album6":{"type":"album","style":"font-size:32.81250rpx;opacity:1;background:#ffffff;margin-top:0px;","li":[{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/91592237508.jpg","title":"\u6c34\u6d52\u4f20","li_class":"album-pic","li_style":"margin-left:32.81250rpx;margin-top:0px;width:325.78125rpx;border-radius:0px;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/71592237543.jpg","title":"\u6709\u4e00\u79cd\u7231\u53eb\u653e\u624b","li_class":"album-pic","li_style":"margin-left:32.81250rpx;margin-top:0px;width:325.78125rpx;border-radius:0px;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/31592237583.jpg","title":"\u7ea2\u697c\u68a6","li_class":"album-pic","li_style":"margin-left:32.81250rpx;margin-top:0px;width:325.78125rpx;border-radius:0px;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"},{"pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/61592237666.jpg","title":"\u540e\u79c0","li_class":"album-pic","li_style":"margin-left:32.81250rpx;margin-top:0px;width:325.78125rpx;border-radius:0px;","img_style":"height:351.56250rpx","text_style":"font-size:32.81250rpx;font-weight:normal;font-style:normal;text-decoration:none;text-align:center;color:#ffffff;position:absolute;background:rgba(0,0,0,.5);"}]}};
                        return mappDate;
                    }
                    function router(){
                        return "page10045";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "必读书目";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [{"compid":"carousel2","carouselObj":"tu"}];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                