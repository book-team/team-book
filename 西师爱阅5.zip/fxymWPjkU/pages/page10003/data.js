
                    function appData(){
                        var mappDate = {"topNav0":"","dividing1":{"type":"dividing","style":"border-bottom-color:rgb(238, 238, 238);width:750.00000rpx;border-width:2.34375rpx;margin-top:2.34375rpx;margin-left:0px;margin-right:0px;border-bottom-style:solid;display:block;","content":""},"dividing2":{"type":"dividing","style":"border-bottom-color:rgb(238, 238, 238);width:750.00000rpx;border-width:2.34375rpx;margin-top:2.34375rpx;margin-left:0px;margin-right:0px;border-bottom-style:solid;display:block;","content":""},"newpersonalcenter3":{"type":"newpersonalcenter","style":"opacity:1;margin-top:0px;position:relative;","content":[{"text":"\u5e38\u7528\u529f\u80fd","choose":true,"showSec":true,"type":2,"nid":"common","second":[{"text":"\u4e2a\u4eba\u4fe1\u606f","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon1.png","routerlink":"\/peronaldetails","choose":true,"nid":"preinfo"},{"text":"\u501f\u4e66\u8bb0\u5f55","pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/81592258584.png","routerlink":"\/addressmanage","choose":true,"nid":"deladdress"},{"text":"\u9605\u8bfb\u8bb0\u5f55","pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/41592258656.png","routerlink":"\/integralall","choose":true,"nid":"integcity"},{"text":"\u6536\u85cf","pic":"http:\/\/make.suchengapp.com\/upload\/images\/20200615\/51592258663.jpg","routerlink":"\/newCoupon","choose":true,"nid":"coupon"},{"text":"\u4f1a\u5458\u5361","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon5.png","routerlink":"\/membercard","choose":false,"nid":"membercard"},{"text":"\u7535\u5546\u8d2d\u7269\u8f66","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon6.png","routerlink":"\/shoppingcart","choose":false,"nid":"shopcart"},{"text":"\u5e97\u94fa\u7ba1\u7406","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon7.png","routerlink":"\/sellerJoin","choose":false,"nid":"shopmanage"}]},{"text":"\u5fae\u5546\u57ce","choose":false,"showSec":true,"type":1,"nid":"elecity","second":[{"text":"\u5168\u90e8\u8ba2\u5355","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon8.png","routerlink":"\/commodityAllorder?status=-1","choose":true,"nid":"eleall"},{"text":"\u5f85\u4ed8\u6b3e","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon9.png","routerlink":"\/commodityAllorder?status=0","choose":true,"nid":"elewaitpay"},{"text":"\u5f85\u53d1\u8d27","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon10.png","routerlink":"\/commodityAllorder?status=1","choose":true,"nid":"elewaitsend"},{"text":"\u5f85\u6536\u8d27","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon11.png","routerlink":"\/commodityAllorder?status=2","choose":true,"nid":"elewaitget"},{"text":"\u5f85\u8bc4\u4ef7","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon12.png","routerlink":"\/commodityAllorder?status=3","choose":true,"nid":"elewaiteval"},{"text":"\u5f85\u81ea\u63d0","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon37.png","routerlink":"\/commodityAllorder?status=4&navidx=1","choose":true,"nid":"elewaittake"}]},{"text":"\u6211\u7684\u780d\u4ef7","choose":false,"showSec":true,"type":1,"nid":"kanjia","second":[{"text":"\u780d\u4ef7\u8bb0\u5f55","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon33.png","routerlink":"\/haggleList?selidx=-1","choose":true,"nid":"kjall"},{"text":"\u780d\u4ef7\u4e2d","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon34.png","routerlink":"\/haggleList?selidx=0","choose":true,"nid":"kjing"},{"text":"\u780d\u4ef7\u8ba2\u5355","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon35.png","routerlink":"\/haggleOrder","choose":true,"nid":"kjorder"}]},{"text":"\u62fc\u56e2\u4e2d\u5fc3","choose":false,"showSec":true,"type":1,"nid":"pintuan","second":[{"text":"\u8ba2\u5355\u5217\u8868","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon8.png","routerlink":"\/groupgoodsAllorder?status=-1","choose":true,"nid":"ptall"},{"text":"\u62fc\u56e2\u4e2d","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon14.png","routerlink":"\/groupgoodsAllorder?status=0","choose":true,"nid":"ptwait"},{"text":"\u56e2\u957f\u4f63\u91d1","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon15.png","routerlink":"\/groupDeposit","choose":true,"nid":"ptbroke"}]},{"text":"\u79d2\u6740\u4e2d\u5fc3","choose":false,"showSec":true,"type":1,"nid":"miaosha","second":[{"text":"\u5168\u90e8\u8ba2\u5355","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon8.png","routerlink":"\/myseckOrder?status=-1","choose":true,"nid":"msall"},{"text":"\u5f85\u4ed8\u6b3e","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon9.png","routerlink":"\/myseckOrder?status=0","choose":true,"nid":"mswaitpay"},{"text":"\u5f85\u6536\u8d27","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon11.png","routerlink":"\/myseckOrder?status=2","choose":true,"nid":"mswaitget"}]},{"text":"\u8be6\u7ec6\u4fe1\u606f","choose":true,"showSec":true,"type":1,"nid":"fenxiao","second":[{"text":"\u501f\u9605\u91cf","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon16.png","routerlink":"\/mydisOrder","choose":true,"nid":"fxall"},{"text":"\u9605\u8bfb\u91cf","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon17.png","routerlink":"\/myDeposit","choose":true,"nid":"fxbroke"},{"text":"\u6536\u85cf\u91cf","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon36.png","routerlink":"","choose":true,"nid":"fxorder"},{"text":"\u5206\u9500\u4ea7\u54c1","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon18.png","routerlink":"\/disProduct","choose":false,"nid":"fxproduct"},{"text":"\u4e0b\u7ea7\u6210\u5458","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon19.png","routerlink":"","choose":false,"nid":"fxnext"},{"text":"\u6211\u8981\u5206\u9500","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon20.png","routerlink":"\/iWantDis","choose":false,"nid":"fxwant"}]},{"text":"\u5fae\u9910\u996e","choose":false,"showSec":true,"type":1,"nid":"takeout","second":[{"text":"\u5230\u5e97\u8ba2\u5355","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon21.png?t=1","routerlink":"\/takeoutorder\/1","choose":true,"nid":"takeoutdd"},{"text":"\u9884\u7ea6\u8ba2\u5355","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon22.png","routerlink":"\/takeoutorder\/3","choose":true,"nid":"takeoutyy"},{"text":"\u5916\u9001\u8ba2\u5355","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon23.png","routerlink":"\/takeoutorder\/0","choose":true,"nid":"takeoutws"},{"text":"\u81ea\u53d6\u8ba2\u5355","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon24.png","routerlink":"\/takeoutorder\/2","choose":true,"nid":"takeoutzq"}]},{"text":"\u5fae\u540c\u57ce","choose":false,"showSec":true,"type":1,"nid":"tongcheng","second":[{"text":"\u6211\u7684\u8ba2\u5355","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon16.png","routerlink":"\/commodityAllorder","choose":true,"nid":"tcall"},{"text":"\u6211\u53d1\u5e03\u7684","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon25.png","routerlink":"\/citywide\/0","choose":true,"nid":"tcewlease"},{"text":"\u6211\u7684\u8bc4\u8bba","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon26.png?t=1","routerlink":"\/citywide\/1","choose":true,"nid":"tceval"},{"text":"\u56de\u590d\u6211\u7684","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon27.png","routerlink":"\/citywide\/2","choose":true,"nid":"tcreplay"},{"text":"\u6253\u8d4f\u7ba1\u7406","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon28.png","routerlink":"\/rewardManage","choose":true,"nid":"tcmanage"}]},{"text":"\u9152\u5e97\u9884\u8ba2","choose":false,"showSec":true,"type":1,"nid":"jiudian","second":[{"text":"\u6211\u7684\u8ba2\u5355","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon16.png","routerlink":"\/myhotelOrder?status=-1","choose":true,"nid":"jdall"},{"text":"\u5f85\u652f\u4ed8","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon29.png","routerlink":"\/myhotelOrder?status=0","choose":true,"nid":"jdwaitpay"},{"text":"\u9884\u5b9a\u4e2d","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon30.png","routerlink":"\/myhotelOrder?status=2","choose":true,"nid":"jdwaitreserve"}]},{"text":"\u5fae\u9884\u7ea6","choose":false,"showSec":true,"type":1,"nid":"yuyue","second":[{"text":"\u6211\u7684\u9884\u7ea6","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon31.png","routerlink":"\/bespeaklist?status=0","choose":true,"nid":"yyall"},{"text":"\u5f85\u652f\u4ed8","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon29.png","routerlink":"\/bespeaklist?status=2","choose":true,"nid":"yywaitpay"},{"text":"\u9884\u7ea6\u4e2d","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon32.png","routerlink":"\/bespeaklist?status=1","choose":true,"nid":"yywaiting"}]},{"text":"\u4e2d\u5956\u8bb0\u5f55","choose":false,"showSec":true,"type":1,"nid":"prize","second":[{"text":"\u5927\u8f6c\u76d8","pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_icon38.png","routerlink":"\/turntableList","choose":true,"nid":"dazhuanpan"}]}],"piccontent":{"pic":"http:\/\/make.suchengapp.com\/static\/user\/images\/newperbg.jpg"},"topstyle":"color:#ffffff;font-size:30.46875rpx;font-style:normal;font-weight:normal;text-decoration:none;","avatarstyle":"width:110.15625rpx;height:110.15625rpx;","jifenstyle":"color:#ffffff;font-size:37.50000rpx;font-style:normal;font-weight:normal;text-decoration:none;","modelstyle":"color:#353535;font-size:30.46875rpx;font-style:normal;font-weight:normal;text-decoration:none;","styletype":1,"isintegral":false,"isnotice":true,"ricon":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_right.png","dicon":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_down.png","newclose":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_closeshare.png","newshare1":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_share1.png","newshare2":"http:\/\/make.suchengapp.com\/static\/user\/images\/newper_share2.png","themeColor":"#ef5b5b","compid":"newpersonalcenter3"}};
                        return mappDate;
                    }
                    function router(){
                        return "page10003";
                    }
                    function articles(){
                        return [];
                    }
                    function comments(){
                        return [];
                    }
                    function title(){
                        return "我的";
                    }
                    function dymanicList(){
                        return [];
                    }
                    function countArr(){
                        return [];
                    }
                    function goodsArr(){
                        return [];
                    }
                    function forumArr(){
                        return [];
                    }
                    function topicArr(){
                        return [];
                    }
                    function cityArr(){
                        return [];
                    }
                    function shopArr(){
                        return [];
                    }
                    function groupGoodsArr(){
                        return [];
                    }
                    function takeoutArr(){
                        return [];
                    }
                    function carouselArr(){
                        return [];
                    }
                    function seckillArr(){
                        return [];
                    }
                    function newseckillArr(){
                          return [];
                    }
                    function goodsClaArr(){
                        return [];
                    }
                    function listDetailArr(){
                        return [];
                    }
                    function productArr(){
                        return [];
                    }
                    function takeoutShopArr(){
                        return [];
                    }
                    function distributeArr(){
                        return [];
                    }
                    function theCityArr(){
                        return [];
                    }
                    function newgoodsArr(){
                        return [];
                    }
                    function serviceArr(){
                        return [];
                    }
                    function techArr(){
                        return [];
                    }
                    function appointShopArr(){
                        return [];
                    }
                    function bargainArr(){
                        return [];
                    }
                    function subGoodsArr(){
                        return [];
                    }
                    function cityMerArr(){
                        return [];
                    }
                    function newsearchArr(){
                        return [];
                    }
                    function newdistributeArr(){
                        return [];
                    }
                    function noticeArr(){
                        return [];
                    }
                    function couponlistArr(){
                        return [];
                    }
                    function goodsShopArr(){
                        return [];
                    }
                    function houseApartArr(){
                        return [];
                    }
                    function videoArr(){
                        return [];
                    }
                    function hotelListArr(){
                        return [];
                    }
                    function hotelSoArr(){
                        return [];
                    }
                    function appJumpArr(){
                        return [];
                    }
                    function newpersonArr(){
                        return [{"name":"newpersonalcenter3"}];
                    }
                    function newAudioArr(){
                        return [];
                    }
                    function busicardArr(){
                        return [];
                    }
                    function addXcxTip(){
                        return "0";
                    }

                    module.exports={
                        appData: appData,
                        router:router,
                        articles:articles,
                        comments:comments,
                        title:title,
                        dymanicList:dymanicList,
                        countArr:countArr,
                        goodsArr:goodsArr,
                        forumArr:forumArr,
                        topicArr:topicArr,
                        cityArr:cityArr,
                        shopArr:shopArr,
                        groupGoodsArr:groupGoodsArr,
                        takeoutArr:takeoutArr,
                        carouselArr:carouselArr,
                        seckillArr:seckillArr,
                        newseckillArr:newseckillArr,
                        distributeArr:distributeArr,
                        goodsClaArr:goodsClaArr,
                        listDetailArr:listDetailArr,
                        productArr:productArr,
                        takeoutShopArr:takeoutShopArr,
                        theCityArr:theCityArr,
                        newgoodsArr:newgoodsArr,
                        serviceArr:serviceArr,
                        techArr:techArr,
                        appointShopArr:appointShopArr,
                        bargainArr:bargainArr,
                        subGoodsArr:subGoodsArr,
                        cityMerArr:cityMerArr,
                        newsearchArr:newsearchArr,
                        newdistributeArr:newdistributeArr,
                        noticeArr:noticeArr,
                        couponlistArr:couponlistArr,
                        goodsShopArr:goodsShopArr,
                        houseApartArr:houseApartArr,
                        videoArr:videoArr,
                        hotelListArr:hotelListArr,
                        hotelSoArr:hotelSoArr,
                        appJumpArr:appJumpArr,
                        newpersonArr:newpersonArr,
                        newAudioArr:newAudioArr,
                        busicardArr:busicardArr,
                        addXcxTip:addXcxTip
                    }
                