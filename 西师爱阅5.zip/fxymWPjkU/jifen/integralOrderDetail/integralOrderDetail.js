var app = getApp();
var id;
Page({
    data: {
    },
    onLoad: function (e) {
        id = e.id;
        app.addIplog();
        this.loadData();
    },
    backhome: function () {
        app.backhome();
    },
    goBack: function () {
        app.turnBack();
    },
    loadData: function () {
        var that = this;
        app.sendRequest({
            url: '/webapp/exchange_detail',
            method: 'post',
            data: {
                id: id
            },
            success: function (res) {
                var newdata = {};
                if (res.code == 1) {
                    newdata['goodsname'] = res.exchange_good.goodsname;
                    newdata['goodspic'] = res.exchange_good.goodspic;
                    newdata['needintegral'] = res.exchange_good.integral;
                    newdata['delivered'] = res.exchange_good.status;
                    newdata['price'] = res.exchange_good.price;
                    newdata['deliveredComp'] = res.exchange_good.express;
                    newdata['deliveredId'] = res.exchange_good.expressnum;
                    newdata['orderId'] = res.exchange_good.order_id;
                    newdata['need_address'] = res.exchange_good.need_address;
                    that.setData(newdata);
                }
            }
        });
    }
});