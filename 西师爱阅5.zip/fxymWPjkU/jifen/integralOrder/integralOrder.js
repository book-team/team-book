var app = getApp();
Page({
    prenum: 0,
    pagenum: 1,
    havenums: 1,
    data: {
    },
    onLoad: function (e) {
        app.addIplog();
        this.loadData();
    },
    backhome: function () {
        app.backhome();
    },
    loadmore: function () {
        var prenum = this.prenum;
        var pagenum = this.pagenum;
        var havenums = this.havenums;
        if (prenum != pagenum && havenums != 0) {
            this.prenum = pagenum;
            this.loadData();
        }
    },
    loadData: function () {
        var that = this;
        var searchText = this.data.searchText;
        var pagenum = this.pagenum;
        app.sendRequest({
            url: '/webapp/exchange_list',
            method: 'post',
            data: {
                openid: app.getSessionKey(),
                pageNum: pagenum,
            },
            success: function (res) {
                var newdata = {};
                newdata['nothing'] = true;
                if (res.code == 1) {
                    that.havenums = res.havenums;
                    that.pagenum = that.pagenum + 1;
                    var oldlist = that.data.integralOrder || [];
                    newdata['integralOrder'] = oldlist.concat(res.list);
                }
                that.setData(newdata);
            }
        });
    },
    orderDetail: function (e) {
        var id = app.getset(e).id;
        var url = '/jifen/integralOrderDetail/integralOrderDetail?id=' + id;
        app.turnToPage(url);
    }
})