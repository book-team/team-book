var app = getApp();
var WxParse = require('../../components/wxParse/wxParse.js');
var id;
Page({
    prenum: 0,
    pagenum: 1,
    havenums: 1,
    data: {
        addrIdx: 0,
        addressid: 0,
        successBg_pic: app.globalData.siteBaseUrl + '/static/user/images/successBg.jpg',
    },
    onLoad: function (e) {
        id = e.id;
        app.addIplog();
        app.checkLogin();
    },
    onShow: function () {
        app.setPageUserInfo();
        var that = this;
        var sWidth;
        wx.getSystemInfo({
            success: function (res) {
                sWidth = res.windowWidth - 20;
            }
        })
        app.sendRequest({
            url: '/webapp/integralGoodDetail',
            method: 'post',
            data: {
                id: id,
                openid: app.getSessionKey(),
                addressid: that.data.addressid
            },
            success: function (res) {
                var newdata = {};
                if (res.code == 1) {
                    var article = res.integral_goods.introduce;
                    article = article.replace(/px\)/g, '/320*' + sWidth + 'px)');
                    WxParse.wxParse('article', 'html', article, that, 5);
                    newdata['addressinfo'] = res.address || {};
                    newdata['goodspic'] = res.integral_goods.goodspic;
                    newdata['goodsname'] = res.integral_goods.goodsname;
                    newdata['needintegral'] = res.integral_goods.needintegral;
                    newdata['price'] = res.integral_goods.price;
                    newdata['hasAddress'] = res.hasAddress;
                    newdata['need_ddress'] = res.integral_goods.need_address;
                    newdata['process'] = res.integral_goods.process;
                    newdata['attention'] = res.integral_goods.attention;
                    newdata['noIntegral'] = res.noIntegral;
                    that.setData(newdata);
                    wx.setNavigationBarTitle({
                        title: res.integral_goods.goodsname
                    });
                } else if (res.code == 1000 || res.code == 2000) {
                    that.setData({
                        vqdlevel: res.code
                    })
                    wx.setNavigationBarTitle({
                        title: '待升级提示'
                    });
                }
            }
        });
    },
    dataInitial: function () {
    },
    onShareAppMessage: function () {
        var pageRouter = this.page_router;
        app.sendRequest({
            url: '/webapp/tjIntegral',
            data: {
                openid: app.getSessionKey()
            },
            method: 'POST',
            success: function (res) {
            }
        });
        return {
            title: app.getAppTitle(),
            desc: app.getAppDescription(),
            path: '/jifen/integralMall/integralMall',
            success: function (res) {
            }
        }
    },
    backhome: function () {
        app.backhome();
    },
    selectAddress: function () {
        var addrIdx = this.data.addrIdx;
        var url = '/pages/selAddress/selAddress?addrIdx=' + addrIdx + '&type=0';
        app.turnToPage(url);
    },
    clickExchange: function () {
        var that = this;
        app.showModal({
            content: '确定使用' + this.data.needintegral + '积分兑换该商品？',
            showCancel: true,
            confirm: function () {
                that.sureExchange();
            }
        })
    },
    sureExchange: function () {
        var that = this;
        var openid = app.getSessionKey();
        var avatar = this.data.userInfo.avatarUrl;
        var nickname = this.data.userInfo.nickName;
        var address = this.data.addressinfo.address;
        var consignee = this.data.addressinfo.consignee;
        var telphone = this.data.addressinfo.telphone;
        app.sendRequest({
            url: '/webapp/exchangeGoods',
            method: 'post',
            data: {
                goodid: id,
                openid: openid,
                avatar: avatar,
                nickname: nickname,
                address: address,
                consignee: consignee,
                telphone: telphone
            },
            success: function (res) {
                var newdata = {};
                if (res.code == 1) {
                    that.setData({
                        oid: res.id,
                        successPromit: 1
                    });
                } else if (res.code == 2) {
                    app.showModal({
                        content: '商品数量不足'
                    })
                } else if (res.code == 3) {
                    app.showModal({
                        content: '积分不足，无法兑换'
                    })
                } else {
                    app.showModal({
                        content: '兑换失败，请重试'
                    })
                }
            }
        });
    },
    hidePromit: function () {
        this.setData({
            successPromit: 0
        })
    },
    orderDetail: function () {
        var id = this.data.oid;
        var url = '/jifen/integralOrderDetail/integralOrderDetail?id=' + id;
        app.turnToPage(url);
        this.hidePromit();
    },
    noAddress: function () {
        app.showModal({
            content: '亲-请先填写地址，方可提交订单，谢谢。',
        })
    },
    clickAuthor: function () {
        app.clickAuthor();
    },
    getuserinfo: function (e) {
        app.getuserinfo(e);
    },
    closenewgift: function () {
        app.closenewgift();
    },
    openAuthor: function () {
        app.openAuthor();
    },
    refuseAuthor: function () {
        app.refuseAuthor();
    }
})